({
    
    getAllOSTLists : function(component){
        console.log('in MasterDetailEdit Helper getAllOSTLists');        
        var action = component.get("c.getAllOSTLists");
        action.setParams({"accountPlanId": component.get("v.recordId")});
        action.setCallback(this, function(resp) {
            if(resp.getReturnValue() == null){
                this.createEmptyOSTData(component);
            }else{
                var map = resp.getReturnValue()
                for(var key in map)
                {
                    for(var i = 0 ; i < map[key].length ; i++)
                    {
                        var mapKeyVal = map[key];
                        if('objective' == key){
                            component.set("v.ObjectiveList", mapKeyVal); 
                        }else if('strategy' == key){
                            component.set("v.StrategyList", mapKeyVal); 
                        }else if('tactic' == key){
                            component.set("v.TacticList", mapKeyVal); 
                        }
                    }
                }
            }
        });
        $A.enqueueAction(action);
    },

    
    // get the objectList from component and add(push) New Object to List
    createEmptyOSTData: function(component, event) {
        console.log('in MasterDetailEdit Helper createOSTData');
        
        var ObjectiveList = component.get("v.ObjectiveList");
        	var count = ObjectiveList.length;
        	count = count + 1;
        	var tempObjId = 'O' + count;
        var StrategyList = component.get("v.StrategyList");
        	var count1 = StrategyList.length; 
        	count1 = count1 + 1;
        	var tempStratId = 'S' + count1;          
        if(ObjectiveList.length == 0){
            ObjectiveList.push({sobjectType: 'Account_Plan_Objective__c', Account_Plan__c: component.get("v.recordId"), Objective_External__c: tempObjId, Objective_Description__c: '', Desired_Results__c: ''});   
            component.set("v.ObjectiveList", ObjectiveList);
        }
        
        var StrategyList = component.get("v.StrategyList");
        if(StrategyList.length == 0){        
            StrategyList.push({sobjectType: 'Account_Plan_Strategy__c', Account_Plan_Objective__c: tempObjId, Strategy_External__c: tempObjId+tempStratId, Strategy_Description__c: '', Desired_Results__c: '', Results_Summary__c: '' });   
            component.set("v.StrategyList", StrategyList);
        }
        
        var TacticList = component.get("v.TacticList");
        if(TacticList.length == 0){
            TacticList.push({sobjectType: 'Account_Plan_Tactic__c', Account_Plan_Strategy__c:(tempObjId + tempStratId), Tactic_Description__c: '', Status__c: '', Start_Date__c: '', Due_Date__c: '', Lead_Contact_Retailer__c: '', Lead_Contact_Winfield__c: ''});   
            component.set("v.TacticList", TacticList);
        }
    },
    
    addNewOSTRowData: function(component, event) {
        console.log('in MasterDetailEdit Helper createObjectiveRowonAdd event section: ' + event.getParam("ostsection") + event.getParam("parentId") + event.getParam("parentExtId"));
        var ostsection = event.getParam("ostsection");
        var ObjectiveList = component.get("v.ObjectiveList");
        var StrategyList = component.get("v.StrategyList");
        var TacticList = component.get("v.TacticList");        
        var objtId = null;
        var stratid = null;

                var count = ObjectiveList.length;
                count = count + 1;
                var tempObjId = 'O' + count;
            
                var count1 = StrategyList.length; 
                count1 = count1 + 1;
                var tempStratId = 'S' + count1;   
        
       if('objective' == ostsection){          
                ObjectiveList.push({sobjectType: 'Account_Plan_Objective__c', Account_Plan__c: component.get("v.recordId"), Objective_External__c: tempObjId, Objective_Description__c: '', Desired_Results__c: '' });   
                component.set("v.ObjectiveList", ObjectiveList);
            
                StrategyList.push({sobjectType: 'Account_Plan_Strategy__c', Account_Plan_Objective__c: tempObjId, Strategy_External__c: tempObjId+tempStratId, Strategy_Description__c: '', Desired_Results__c: '', Results_Summary__c: '' });   
                component.set("v.StrategyList", StrategyList);

                TacticList.push({sobjectType: 'Account_Plan_Tactic__c', Account_Plan_Strategy__c: tempObjId+tempStratId, Tactic_Description__c: '', Status__c: '', Start_Date__c: '', Due_Date__c: '', Lead_Contact_Retailer__c: '', Lead_Contact_Winfield__c: ''});   
                component.set("v.TacticList", TacticList);
       }else if('strategy' == ostsection){
                var parentExtId = event.getParam("parentExtId");
                var parentId = event.getParam("parentId");
                var tempObjId = null;
                var count = 0;
               if(parentId != null){
                   tempObjId = parentId;
               }else{
                   tempObjId = parentExtId;
               } 
                var StrategyList = component.get("v.StrategyList"); //Filter against the parent.
                  for(let j=0; j<StrategyList.length; j++){
                          if(StrategyList[j].Account_Plan_Objective__c!=null && tempObjId == StrategyList[j].Account_Plan_Objective__c){
                              count = count + 1;
                          }
                  }
           		StrategyList.push({sobjectType: 'Account_Plan_Strategy__c', Account_Plan_Objective__c: tempObjId, Strategy_External__c: tempObjId + tempStratId, DeleteFlag__c: true, Strategy_Description__c: '', Desired_Results__c: '', Results_Summary__c: '' });   
                component.set("v.StrategyList", StrategyList);

                    TacticList.push({sobjectType: 'Account_Plan_Tactic__c', Account_Plan_Strategy__c: tempObjId+tempStratId, Tactic_Description__c: '', Status__c: '', Start_Date__c: '', Due_Date__c: '', Lead_Contact_Retailer__c: '', Lead_Contact_Winfield__c: ''});   
                    component.set("v.TacticList", TacticList);
       	}else if('tactic' == ostsection){
                    var parentExtId = event.getParam("parentExtId");
                    var parentId = event.getParam("parentId");
                    var tempStratId = null;
                       if(parentId != null){
                           tempStratId = parentId;
                       }else{
                           tempStratId = parentExtId;
                       } 
                
                    for(let j=0; j<TacticList.length; j++){
                        if(TacticList[j].Account_Plan_Tactic__c!=null && tempObjId == TacticList[j].Account_Plan_Tactic__c){
                            count = count + 1;
                        }
                    }           
            		TacticList.push({sobjectType: 'Account_Plan_Tactic__c', Account_Plan_Strategy__c: tempStratId, DeleteFlag__c: true, Tactic_Description__c: '', Status__c: '', Start_Date__c: '', Due_Date__c: '', Lead_Contact_Retailer__c: '', Lead_Contact_Winfield__c: ''});   
                    component.set("v.TacticList", TacticList);
       		} 
 
    },


    // helper function for check if first Name is not null/blank on save  
    validateRequired: function(component, event) {
        debugger;

        var isValid = true;
        var allRows = null;
        var section = component.get("v.section");
        
        allRows = component.get("v.ObjectiveList");
        for (var indexVar = 0; indexVar < allRows.length; indexVar++) {
            if (allRows[indexVar].Objective_Description__c == null || allRows[indexVar].Objective_Description__c == '') {
                isValid = false;
                alert('Objective Type Can\'t be Blank on Row Number ' + (indexVar + 1));
            }
        }
        return isValid;    
    },    
    
    deleteOSTRowData :  function(component, event, helper){
        var ostsection = event.getParam("ostsection");
        if('objective' == ostsection){
            var id = event.getParam("id");                
            var objtId = event.getParam("parentId");
            var objtExtId = event.getParam("parentExtId");
            var rowIndex = event.getParam("indexVar");
            var stratExtId = null;
            var objectiveList = null;
            var strategyList= null;
            var TacticList = null;           
            objectiveList = component.get("v.ObjectiveList");
                if(id == null){
                    objectiveList.splice(rowIndex, 1);
                    component.set("v.ObjectiveList", objectiveList);
                    if(objtExtId != null){
                        
                			strategyList  = component.get("v.StrategyList");
                            for(let i=0; i<strategyList.length; i++){
                                if(objtExtId == strategyList[i].Account_Plan_Objective__c){
                                    stratExtId = strategyList[i].Strategy_External__c;
                                    strategyList.splice(i, 1);
                                    component.set("v.StrategyList", strategyList);
                                }
                            }
                        
                        if(stratExtId !=null){
                            
                             TacticList = component.get("v.TacticList"); 
                                for(let j=0; j<TacticList.length; j++){
                                    if(stratExtId == TacticList[j].Account_Plan_Strategy__c){
                                        TacticList.splice(j, 1);
						                component.set("v.TacticList", TacticList); 
                                    }
                                }
                        }
                    }
                }else{
                    var action = component.get("c.deleteObjective");
                    action.setParams({"objectiveList": objectiveList, "objtid": id});
                    action.setCallback(this, function(response) {
                        var state = response.getState();
                        if (state === "SUCCESS") {
                            this.getAllOSTLists(component);
                            component.set("v.notifMsgObjective", "Removed Objective Successfully!");                        
                        }
                    });
                    $A.enqueueAction(action);                
                }
            }else if('strategy' == ostsection){
                
                var id = event.getParam("id");
                var stratExtId = event.getParam("extid");
                
                var rowIndex = event.getParam("indexVar");                
                var strategyList  = component.get("v.StrategyList");
                
                var parentExtId = event.getParam("parentExtId");
                var parentId = event.getParam("parentId");
                
                var tempObjId = null;
                var count = 0;
                   if(parentId != null){
                       tempStratId = parentId;
                   }else{
                       tempStratId = parentExtId;
                   } 
                
                if( id == null & stratExtId != null ){
                	strategyList.splice(rowIndex, 1);

                        var TacticList = component.get("v.TacticList"); 
                            for(let i=0; i < TacticList.length; i++){
                                if(stratExtId == TacticList[i].Account_Plan_Strategy__c){
                                    TacticList.splice(i, 1);
                                }
                            }
						component.set("v.TacticList", TacticList);                         
                    
                }else{
                    var action = component.get("c.deleteStrategy");
                    action.setParams({"strategyList": strategyList, "stratid": id});
                    action.setCallback(this, function(response) {
                        var state = response.getState();
                        if (state === "SUCCESS") {
                            this.getAllOSTLists(component);
                            component.set("v.notifMsgObjective", "Removed Objective Successfully!");                        
                        }
                    });
                    $A.enqueueAction(action);                
                }
                
                for(let j=0; j<strategyList.length; j++){
                    if(strategyList[j].Account_Plan_Objective__c!=null && tempObjId == strategyList[j].Account_Plan_Objective__c){
                        count = count + 1;
                    }
                }
                
                if(count == 0){
                    for(let j=0; j<strategyList.length; j++){
                    	strategyList[j].DeleteFlag = false; 
                    }
                }
                
				component.set("v.StrategyList", strategyList); 
                
            }else if('tactic' == ostsection){
                var id = event.getParam("id");                 
                var stratId = event.getParam("parentId");
                var stratExtId = event.getParam("parentExtId");
                var rowIndex = event.getParam("rowIndex");
				var count = 0;
                    var parentExtId = event.getParam("parentExtId");
                    var parentId = event.getParam("parentId");
                    var tempStratId = null;
               
                   if(parentId != null){
                       tempStratId = parentId;
                   }else{
                       tempStratId = parentExtId;
                   } 
                    
           		var TacticList = component.get("v.TacticList");
                  for(let j=0; j<TacticList.length; j++){
                          if(TacticList[j].Account_Plan_Tactic__c!=null && tempObjId == TacticList[j].Account_Plan_Tactic__c){
                              count = count + 1;
                          }
                  }                  
                
                if(id == null){
                    var index = event.getParam("indexVar");
                    TacticList.splice(index, 1);
                }else{
                    var action = component.get("c.deleteTactic");
                    action.setParams({"tacticList": component.get("v.TacticList"), "tactId": id});
                    action.setCallback(this, function(response) {
                        var state = response.getState();
                        if (state === "SUCCESS") {
                            this.getAllOSTLists(component);
                            component.set("v.notifMsgTactic", "Removed Tactic Successfully!");                        
                        }
                    });
                    $A.enqueueAction(action);                
                }                
       }
        
                   	if(count == 0){
                    	for(let j=0; j<TacticList.length; j++){
                    	TacticList[j].DeleteFlag = false; 
                    }
                }
        component.set("v.TacticList", TacticList);
    }, 
})