({
    doInit : function(component, event, helper) {
        console.log('in MasterDetailEdit Controller doInit');
        var today = new Date();
        component.set('v.today', today.getFullYear() + "-" + (today.getMonth() + 1) + "-" + today.getDate());
        helper.getAllOSTLists(component); 
        var action = component.get("c.assigntab");
        action.setParams({
            "accountPlanId": component.get("v.recordId"),
            "selectedtab": component.get("v.Mastertab")
        })
        action.setCallback(this, function(response) {
                    var state = response.getState();
                    if (state === "SUCCESS") {
                        //console.log('Assign Tab Save SUCCESS!!');
                    }else{
                            console.log('Save CriticalIssue Error !! ' + state);
                        }
        });
        $A.enqueueAction(action);  
    },
    
    save: function(component, event, helper) {
    	var action = component.get("c.saveAllOST");
        console.log('in newsave component.get("v.ObjectiveList").length: ' + component.get("v.ObjectiveList").length);
        console.log('in newsave component.get("v.StrategyList").length: ' + component.get("v.StrategyList").length);
        console.log('in newsave component.get("v.TacticList").length: ' + component.get("v.TacticList").length);

           	var tList = component.get("v.TacticList");
           	console.log('In Master TacticList Save');        
       		console.log('tact size: ' + tList.length);
           for(let i=0; i<tList.length; i++){
               console.log('tact Account_Plan_Strategy__c: ' + tList[i].Account_Plan_Strategy__c);
               console.log('tact Tactic_Description__c: ' + tList[i].Tactic_Description__c);
           }
        
        action.setParams({"objtList": component.get("v.ObjectiveList"), 
                           "stratList": component.get("v.StrategyList"),
                           "tactList": component.get("v.TacticList"),                        
                           "accountPlanId": component.get("v.recordId")}); 
        
        action.setCallback(this, function(response) {
                var state = response.getState();
                if (state === "SUCCESS") {
                    helper.getAllOSTLists(component);
                        component.set("v.viewEditFlag", "Cancel");
                        component.set("v.disableViewBtn", true);
                        component.set("v.disableEditBtn", false);
                        component.set("v.ShowMessage", false);
                          //alert('Your Objectives changes have been saved successfully!');
                }else{
                        console.log('Save Error !! ' + state);
                     }
            });
            $A.enqueueAction(action);
    },

    addNewOSTRow :  function(component, event, helper){
            helper.addNewOSTRowData(component, event);
    },
    
    deleteOSTRow :  function(component, event, helper){
            helper.deleteOSTRowData(component, event);
    }, 
    objectivePdfGenerator: function (component, event, helper) {
        var recordId = component.get("v.recordId");
      window.setTimeout(
      $A.getCallback(function() {
          	     window.open(
                      '/apex/AccountPlanObjectivePdf?id='+recordId,
                      '_blank' 
                  );
    		 }), 1000
  		);
 },
    toggleViewEdit: function(component, event, helper) {  
        if('Cancel' == event.getSource().get("v.label")){
            component.set("v.viewEditFlag", "Cancel");
            component.set("v.disableViewBtn", true);
            component.set("v.disableEditBtn", false);
            component.set("v.ShowMessage", false);
        }else {
            component.set("v.ShowMessage", false);
            component.set("v.viewEditFlag", "edit");
            component.set("v.disableViewBtn", false);
            component.set("v.disableEditBtn", true);
            
        }
    },    
})