({
    
    doInit:function(component, event, helper){

        console.log('component.get("v.tactic.Id") ' + component.get("v.tactic.Id"));
        if(component.get("v.tactic.Id") != null){
        console.log('tact doInit');
        var wfcontact= component.get("v.tactic.Lead_Contact_Winfield__r.Id");
        var rtcontact = component.get("v.tactic.Lead_Contact_Retailer__r.Id");
            if(wfcontact != null){
                var action = component.get("c.getContact");
                action.setParams({
                    "id": wfcontact
                })
                action.setCallback(this, function(response) {
                            var state = response.getState();
                            if (state === "SUCCESS") {
                                //console.log('Assign Tab Save SUCCESS!!');
                                    component.set("v.selectedUserLookUpRecord", response.getReturnValue() );
                            }else{
                                    console.log('Save CriticalIssue Error !! ' + state);
                                }
                });
                $A.enqueueAction(action);   
            } 
            if(rtcontact != null){
                var action = component.get("c.getContact");
                action.setParams({
                    "id": rtcontact
                })
                action.setCallback(this, function(response) {
                            var state = response.getState();
                            if (state === "SUCCESS") {
                                //console.log('Assign Tab Save SUCCESS!!');
                                    component.set("v.selectedContactLookUpRecord", response.getReturnValue() );
                            }else{
                                    console.log('Save CriticalIssue Error !! ' + state);
                                }
                });
                $A.enqueueAction(action);   
            }             
        }
    },
	addtacticrow : function(component, event, helper){
        component.getEvent("AddNewRowOSTEvt").setParams( {"ostsection" : "tactic", "parentExtId": component.get("v.parentExtId"), "parentId": component.get("v.parentId")} ).fire();     
    },
    
    removetacticrow :function(component, event, helper){
        component.getEvent("DeleteRowOSTEvt").setParams( {"ostsection" : "tactic", "parentExtId": component.get("v.parentExtId"), "parentId": component.get("v.parentId"), "id": component.get("v.tactic.Id"), "indexVar" : component.get("v.rowIndex") }).fire();
    },

    
    handleComponentEvent : function(component, event, helper) {
    // get the selected Account record from the COMPONENT event 
		
        console.log('In handleComponentEvent in tactds : '+ event.getParam("objectAPIName") + ' ' + event.getParam("recordByEvent") + ' '+ event.getParam("recordByEvent").Id + ' '+ event.getParam("recordByEvent").Name);	 

        var selectedItem = event.getParam("recordByEvent");
        var objectAPIName = event.getParam("objectAPIName");
        var optionType = event.getParam("optionType");

        console.log('selectedItem Id in tactic ds: ' + selectedItem.Id);
        
		if('Contact_Winfield' ==  optionType){
            console.log('Inside Contact_Winfield');
        	component.set("v.selectedUserLookUpRecord" , event.getParam("recordByEvent"));     
            component.set("v.tactic.Lead_Contact_Winfield__c", event.getParam("recordByEvent").Id);
        }else if('Contact_Retailer' ==  optionType){
            console.log('Inside Contact_Retailer');
       		component.set("v.selectedContactLookUpRecord" , event.getParam("recordByEvent"));      
            component.set("v.tactic.Lead_Contact_Retailer__c", event.getParam("recordByEvent").Id); 
        }

        console.log('component.get("v.tactic.Lead_Contact_Winfield__c": ' + component.get("v.tactic.Lead_Contact_Winfield__c"));
        console.log('component.get("v.tactic.Lead_Contact_Retailer__c": ' + component.get("v.tactic.Lead_Contact_Retailer__c"));        
        
    },
    
})