({
	
    // Should the delete button/icon be displayed?
    deleteTacticDisplay :  function(component) {
         //console.log('Inside deleteTacticDisplay');
        var count = 0;
        var parId = null;
        var parentId = component.get("v.parentId"); 
        var parentExtId = component.get("v.parentExtId");
        var tList = component.get("v.tacticList");
        
        //console.log('tList.length: ' + tList.length);
        //console.log('parentId: ' + parentId);
        //console.log('parentExtId: ' + parentExtId);
        
        if(parentId != null){
			parId = parentId; 
        }else if (parentExtId != null){
            parId = parentExtId;
        }

            for(let i=0; i<tList.length; i++){
                if(parId == tList[i].Account_Plan_Strategy__c){
                    count = count+1;
                }
            }
        if(count > 1){
			component.set("v.deletedisp", true);            
        }else{
			component.set("v.deletedisp", false);            
        }
    },
    
})