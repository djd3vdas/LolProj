({
    doInit: function(component, event, helper) {
         component.set('v.showSpinner',true);
        var action = component.get("c.checkLockedPlans");
        // Add callback behavior for when response is received
        action.setCallback(this, function(response) {
            var state = response.getState();
            //alert(state);
            var getReturnVal=response.getReturnValue();
            if (state === "SUCCESS") {
                var toastEvent = $A.get("e.force:showToast");
                if(getReturnVal==false){
                    toastEvent.setParams({
                        "title": "Success!",
                        "message": "You cannot perform this action as there are no Locked Policies.",
                        "type":"success"
                    });
                     component.set('v.showModal',false);
                     toastEvent.fire();
                     var dismissActionPanel = $A.get("e.force:closeQuickAction");
                     dismissActionPanel.fire();
                     window.history.back(); 
                     component.set('v.showSpinner',false);
                     setTimeout(function() {
                         location.reload();
                	 }, 900);

                    }else{ 
                        component.set('v.showModal',true);
                        component.set('v.showData',true);
                }
            }
                        
        });
        // Send action off to be executed
        $A.enqueueAction(action);
    },
    
	doOk: function(component, event, helper) {
        
         //component.set('v.showSpinner',true);
        // Create the action
        var action = component.get("c.updatePCStatusEnrolled");
        // Add callback behavior for when response is received
        action.setCallback(this, function(response) {
            var state = response.getState();
            alert(state);
            var getReturnVal=response.getReturnValue();
            alert('getReturnVal:'+getReturnVal);
            if (state === "SUCCESS") {
                var toastEvent = $A.get("e.force:showToast");
                if(getReturnVal=='true'){
                    alert('inside true');
                    toastEvent.setParams({
                        "title": "Success!",
                        "message": "This will unlock the locked Policy. Would you like to proceed?",
                        "type":"success"
                    });                   	 
                }else if(getReturnVal=='false'){
                     toastEvent.setParams({
                        "title": "Warning!",
                        "message": "Status is not defined!",
                        "type":"warning"
                    });
                   
                }
                 component.set('v.showSpinner',false);
                 toastEvent.fire();
                 $A.get("e.force:closeQuickAction").fire();
                 $A.get('e.force:refreshView').fire();                
            }
            else {
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "title": "Error!",
                    "message": "Error while Updating the status!",
                    "type":"error"
                });
                component.set('v.showSpinner',false);
                toastEvent.fire();
                $A.get("e.force:closeQuickAction").fire();
                $A.get('e.force:refreshView').fire();
            }
        });
           window.history.back();
            setTimeout(function() {
                location.reload();
            }, 1000);
        // Send action off to be executed
        $A.enqueueAction(action);
    },
    doCancel: function(component, event, helper) {
         var dismissActionPanel = $A.get("e.force:closeQuickAction");
         dismissActionPanel.fire();
         window.history.back();
    }
    
    
})