({
    /**
     * @name:    doInit
     * @description: This method is handler method of WarrantyCoverageEdit component and hence it will be
     *      call on the time of component initial load.
     *      This method is responsible to fetch the existing record.
     **/
    doInit : function(component, event, helper) {
        var action = component.get("c.fetchWCDetails");
        action.setParams({"wcId": component.get("v.recordId")});
        
        action.setCallback(this, function(response){
            //<response.getState()> return response status as SUCCESS/ERROR/INCOMPLETE etc.
            var state = response.getState();
            console.log("state="+state)
            //If response from server side is <SUCCESS>, then we will set the component attribute "studentObj".
            if (state === "SUCCESS"){
                var responseWCRecord = response.getReturnValue();
                if(responseWCRecord!=null)
                {
                    console.log('responseWCRecord:'+JSON.stringify(responseWCRecord));
                    component.set("v.wc", responseWCRecord);
                    try{
                        if(!responseWCRecord.Product__c)
                        {
                            
                            component.set("v.wcName", "");
                            component.set("v.SearchKeyWord",responseWCRecord.Product__c);
                            component.set("v.wcActualName",responseWCRecord.Product__c);
                        }
                        else
                        {
                            
                            component.set("v.wcName", responseWCRecord.Product__c);
                            component.set("v.SearchKeyWord",responseWCRecord.Product__c);
                            component.set("v.wcActualName",responseWCRecord.Product__c);
                        }
                    }
                    catch(err){
                        component.set("v.wcName", "");
                    }
                }
                else
                {
                    //checking plan configuration status is locked (VSTS-63074)
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Alert!",
                        "message": "The Policy is in Locked/Inactive/void/cancelled Status. You are not allowed to Edit the Warranty Coverage."
                    });
                    toastEvent.fire();
                    //Navigate to detail page.
                    $A.get("e.force:closeQuickAction").fire();
                    $A.get('e.force:refreshView').fire();                    
                }
                
            }
            else if (state === "ERROR") {
                //Error message display logic.
                var errors = response.getError();
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "title": "ERROR!",
                    "message": errors[0].message
                });
                toastEvent.fire();
            }
                else {
                //Unknown message display logic.
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "title": "UNKOWN!",
                    "message": "Unknown error."
                });
                toastEvent.fire();
            }
        });
        
        $A.enqueueAction(action);
    },
    
    keyPressController : function(component, event, helper) {
        // get the search Input keyword   
        
        
        var getInputkeyWord = component.get("v.SearchKeyWord");
        var wcActualName = component.get("v.wcActualName");
        console.log(wcActualName+':elite free xt'+getInputkeyWord);
        
          
        // check if getInputKeyWord size id more then 0 then open the lookup result List and 
        // call the helper 
        // else close the lookup result List part.   
        //if( getInputkeyWord.length > 0 ){
            var forOpen = component.find("searchRes");
            $A.util.addClass(forOpen, 'slds-is-open');
            $A.util.removeClass(forOpen, 'slds-is-close');
            console.log('recordId:'+component.get("v.recordId"));
            helper.searchHelper(component,event,getInputkeyWord,component.get("v.recordId"),wcActualName);
        /*}
        else{
            component.set("v.saveEnable",false);  
            component.set("v.listOfSearchRecords", null ); 
            var forclose = component.find("searchRes");
            $A.util.addClass(forclose, 'slds-is-close');
            $A.util.removeClass(forclose, 'slds-is-open');
        }*/
        
    },
    
	// This function call when the end User Select any record from the result list.   
    handleComponentEvent : function(component, event, helper) {
     
    // get the selected Account record from the COMPONETN event 	 
       var selectedProductGetFromEvent = event.getParam("productByEvent");
	   
       component.set("v.selectedRecord" , selectedProductGetFromEvent); 
       component.set("v.saveEnable",true);
       
        var forclose = component.find("lookup-pill");
           $A.util.addClass(forclose, 'slds-show');
           $A.util.removeClass(forclose, 'slds-hide');
      
        
        var forclose = component.find("searchRes");
           $A.util.addClass(forclose, 'slds-is-close');
           $A.util.removeClass(forclose, 'slds-is-open');
        
        var lookUpTarget = component.find("lookupField");
            $A.util.addClass(lookUpTarget, 'slds-hide');
            $A.util.removeClass(lookUpTarget, 'slds-show');  
      
	},    
    
    /**
     * @name:    doCancel      
     * @description: This method is responsible to cancel or close the modal window.
     **/
    doCancel : function(component, event, helper) {
          $A.get("e.force:closeQuickAction").fire();
                $A.get('e.force:refreshView').fire(); 
                  setTimeout(function() {
                location.reload();
            }, 1000);
    },
    
    // function for clear the Record Selaction 
    clear :function(component,event,heplper){
        
        var pillTarget = component.find("lookup-pill");
        var lookUpTarget = component.find("lookupField"); 
        
        $A.util.addClass(pillTarget, 'slds-hide');
        $A.util.removeClass(pillTarget, 'slds-show');
        
        $A.util.addClass(lookUpTarget, 'slds-show');
        $A.util.removeClass(lookUpTarget, 'slds-hide');
        
        component.set("v.SearchKeyWord",null);
        component.set("v.listOfSearchRecords", null );
    },
    
    /**
     * @name:    doSave      
     * @description: This method is responsible to save warranty coverage record.
     **/
    doSave : function(component, event, helper) {
  /** Server side controller calling logic. **/
        console.log('check:');
        //Calling server side controller's updateWarrantyCoverages() method.
        var action = component.get("c.updateWarrantyCoverages");
        //Set method parameter of updateWarrantyCoverages() method.
        console.log(component.get("v.recordId")+':selectedRecord:'+component.get("v.selectedRecord"));
        action.setParams({
           "wcId": component.get("v.recordId"),
            "productName": component.get("v.selectedRecord")
        });
        
        action.setCallback(this, function(response){
            //<response.getState()> return response status as SUCCESS/ERROR/INCOMPLETE etc.
            var state = response.getState();
            console.log("state1="+state)
            //If response from server side is <SUCCESS>, then we will display a success message.
            if (state === "SUCCESS"){
                //Success message display logic.
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "title": "Success!",
                    "message": "Record has been updated successfully."
                });
                toastEvent.fire();
                //window.parent.location = '/' + component.get("v.wc.Id");
                //Navigate to detail page.
                $A.get("e.force:closeQuickAction").fire();
                $A.get('e.force:refreshView').fire(); 
                
                /*
                	setTimeout(function() {
                //location.reload();
            }, 1000);
                */
                  
            }
            else if (state === "ERROR") {
                //Error message display logic.
                var errors = response.getError();
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "title": "ERROR!",
                    "message": errors[0].message
                });
                toastEvent.fire();
            }else {
                //Unknown message display logic.
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "title": "UNKOWN!",
                    "message": "Unknown error."
                });
                toastEvent.fire();
            }
        });
        
        $A.enqueueAction(action);
 },
    /*
    	// automatically call when the component is done waiting for a response to a server request.  
    hideSpinner : function (component, event, helper) {
        var spinner = component.find('spinner');
        var evt = spinner.get("e.toggle");
        evt.setParams({ isVisible : false });
        evt.fire();    
    },
    // automatically call when the component is waiting for a response to a server request.
    showSpinner : function (component, event, helper) {
        var spinner = component.find('spinner');
        var evt = spinner.get("e.toggle");
        evt.setParams({ isVisible : true });
        evt.fire();    
    },

  
    
    */
    

})