({
	searchHelper : function(component,event,getInputkeyWord,recordId,wcActualName) {
	  // call the apex class method 
     var action = component.get("c.fetchProductList");
      // set param to method  
        action.setParams({
            'searchKeyWord': getInputkeyWord,
            'wcId': recordId
          });
      // set a callBack    
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var storeResponse = response.getReturnValue();
              // if storeResponse size is equal 0 ,display No Result Found... message on screen.
                if (storeResponse.length == 0) {
                    //component.set("v.Message", 'No Result Found...');
                    var getInputkeyWord = component.get("v.SearchKeyWord");
                    console.log('checkwcActualName:'+wcActualName);
                      console.log('elite free xt'+getInputkeyWord);
                      if(getInputkeyWord!=undefined && getInputkeyWord!='' && getInputkeyWord!=null && getInputkeyWord!=wcActualName){
                          component.set("v.saveEnable",true);
                          component.set("v.selectedRecord",getInputkeyWord);
                      }
                } else {
                    //component.set("v.Message", 'Search Result...');
                }
                console.log('storeResponse:'+storeResponse);
                // set searchResult list with return value from server.
                component.set("v.listOfSearchRecords", storeResponse);
            }
 
        });
      // enqueue the Action  
        $A.enqueueAction(action);
    
	},
})