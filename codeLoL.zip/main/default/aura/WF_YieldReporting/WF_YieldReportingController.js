({
	doInit : function(component, event, helper) {
        component.set('v.showMessage',true);
        var actionProfile = component.get("c.configurePlanvalidUser");
        actionProfile.setCallback(this, function(responseP){
          var state = responseP.getState();
         console.log("state="+state)
            //If response from server side is <SUCCESS>, then we will set the component attribute .
            if (state === "SUCCESS"){
                var responseData = responseP.getReturnValue();
                //console.log('responseData=='+responseData);
                if(responseData==false){
                    //Error message display logic.
                    var errors = responseP.getError();
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Information!",
                        "message": 'You dont have the required permission to use this functionality. Kindly, Contact System Administrator.',
                         "type": 'info'
                    });
                    toastEvent.fire();
                    var dismissActionPanel = $A.get("e.force:closeQuickAction");
                    dismissActionPanel.fire();
                }else if(responseData==true){
                     var action = component.get("c.retrieveGrower");
                     action.setParams({"retailerId": component.get("v.recordId")});
            
                     action.setCallback(this, function(response){
                    //<response.getState()> return response status as SUCCESS/ERROR/INCOMPLETE etc.
                    var state = response.getState();
                    console.log("state="+state)
                    //If response from server side is <SUCCESS>, then we will set the component attribute .
                    if (state === "SUCCESS"){
                        var responseData = response.getReturnValue();
                        //console.log('responseData=='+responseData);
                        if(responseData==null){
                            //Error message display logic.
                            var errors = response.getError();
                            var toastEvent = $A.get("e.force:showToast");
                            toastEvent.setParams({
                                "title": "Information!",
                                "message": 'No Grower Found for the Retailer',
                                 "type": 'info'
                            });
                            toastEvent.fire();
                            var dismissActionPanel = $A.get("e.force:closeQuickAction");
                            dismissActionPanel.fire();
                        }else{
                            console.log('recordId=='+component.get("v.recordId"));
                           /* Create dynamic component for solving cache issue*/
                             $A.createComponent(
                                    "c:yieldReportingNew",
                                    { "retailerId": component.get("v.recordId")
                                    },
                                    function(popup, status, errorMessage){
                                        if(status === 'SUCCESS') {
                                            var body = component.get("v.body");
                                            body.push(popup);
                                            component.set("v.body", body); 
                                            /*  var modalPromise = component.find('overlayLib').showCustomModal({
                                                body: popup,
                                                showCloseButton: false
                                            });*/
                                        }
                                    }
                              );
                            
                        }
                        
                    }else if (state === "ERROR") {
                        //Error message display logic.
                        var errors = response.getError();
                        var toastEvent = $A.get("e.force:showToast");
                        toastEvent.setParams({
                            "title": "ERROR!",
                            "message": errors[0].message,
                            "type": 'error'
                        });
                        toastEvent.fire();
                    }else {
                        //Unknown message display logic.
                        var toastEvent = $A.get("e.force:showToast");
                        toastEvent.setParams({
                            "title": "UNKNOWN!",
                            "message": "Unknown error.",
                            "type": 'error'
                        });
                        toastEvent.fire();
                    }
                });
            
            $A.enqueueAction(action);
            }
		}
            
        });
		 $A.enqueueAction(actionProfile);
	}
})