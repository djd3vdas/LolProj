({
    fetchrecordtype : function(component, event, helper) {
        var action = component.get("c.getAccountrecordtype");
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var storeResponse = response.getReturnValue();
                
                // set searchResult list with return value from server.
                component.set("v.recordTypeId", storeResponse);
            }
            
        });
        $A.enqueueAction(action);		
    },
    
    fetchrecordtypeforGrowerDynamic : function(component, event, helper) {
        var action = component.get("c.getgdddrecordtype");
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var storeResponse = response.getReturnValue();
                
                // set searchResult list with return value from server.
                component.set("v.GDDRrecordTypeId", storeResponse);
            }
            
        });
        $A.enqueueAction(action);	
    },
    
    fetchrecordtypeforGrowerStatic : function(component, event, helper) {
        var action = component.get("c.getgsddrecordtype");
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var storeResponse = response.getReturnValue();
                
                // set searchResult list with return value from server.
                component.set("v.GSDDrecordTypeId", storeResponse);
            }
            
        });
        $A.enqueueAction(action);	
    },
    
    fetchrecordtypeforGrowerStaticDollar : function(component, event, helper) {
        var action = component.get("c.getgsdUDrecordtype");
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var storeResponse = response.getReturnValue();
                
                // set searchResult list with return value from server.
                component.set("v.GSDUDrecordTypeId", storeResponse);
            }
            
        });
        $A.enqueueAction(action);	
    },
    
    
    
    getprogramsforretailaccount : function(component,event, helper){
        component.set('v.columns', [
            {label: 'Submitter', fieldName:'Submitter_Name__c', type:'text', editable: false, sortable: true},
            {label: 'Account', fieldName:'Account_Name__c', type:'text', editable: false, sortable: true},
            {label: 'Retailer Account', fieldName: 'Retailer_Account_Name__c', type: 'text', editable: false, typeAttributes: { required: true },sortable: true},
            {label: 'Program', fieldName: 'Program_Name__c', type: 'text', editable: false,  typeAttributes: { required: true },sortable: true   }, 
            {label: 'Final Quantity', fieldName: 'Final_Quantity__c', type: 'number', editable: false, typeAttributes: { required: true },  sortable: true,"cellAttributes": {"class": {"fieldName": "showClass"}}},
            {label: 'Final Amount to Pay', fieldName: 'Final_Amount_to_Pay__c', type: 'currency', editable: false, typeAttributes: { currencyCode: 'USD'},  sortable: true,"cellAttributes": {"class": {"fieldName": "showClass"}}},
            {label: 'Director Approved Amount to Pay', fieldName: 'Director_Approved_Amount_to_Pay__c', type: 'currency', editable: true, typeAttributes: { currencyCode: 'USD'}, typeAttributes: { required: true },sortable: true,"cellAttributes": {"class": {"fieldName": "showClass"}}},
        ]);    
            //helper.getprogramdetails(component, helper);
            // var pageSize = component.get("v.pageSize").toString();       
            // var pageNumber = component.get("v.pageNumber").toString();
            
            var action = component.get("c.getrecordsbyprogramname"); 
            var retailid = component.get("v.selectedRecordIdR");
            var accid = component.get("v.selectedRecordId");
            var userid = component.get("v.selectedRecordIdU");
            var tpbid = component.get("v.selectedRecordIdT");
            
            if(accid == '') accid = null;
        	if(retailid == '') retailid = null;
        	if(tpbid == '') tpbid = null;
            if(userid == '') userid = null;
            
            action.setParams({  retaileraccountid : retailid,
            accountid : accid,
            programname : tpbid,
            Username:userid
            });
            
            action.setCallback(this,function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
            var retailrows = response.getReturnValue();
            //var pageSize = component.get("v.pageSize");               
            var totalfcount = 0;
            var totalamounttopay = 0;
            var totalDAamounttopay = 0;
            for (var i = 0; i < retailrows.length; i++) {
            var retailrow = retailrows[i];
                      //if (retailrow.Account__c)retailrow.Account__c = retailrow.Account__r.Name;
                      //if (retailrow.Retailer_Account__c)retailrow.Retailer_Account__c = retailrow.Retailer_Account__r.Name;
                      
                      if(retailrows[i].Final_Quantity__c!=null){
            totalfcount += parseInt(retailrows[i].Final_Quantity__c);
        }
        if(retailrows[i].Final_Amount_to_Pay__c!=null){
            totalamounttopay += parseInt(retailrows[i].Final_Amount_to_Pay__c);
        }
        if(retailrows[i].Director_Approved_Amount_to_Pay__c!=null){
            totalDAamounttopay += parseInt(retailrows[i].Director_Approved_Amount_to_Pay__c);
        }
    }
    
    component.set("v.totalCostFQ", totalfcount);
    component.set("v.totalCostFAP", totalamounttopay);
    component.set("v.totalCostDAAP",totalDAamounttopay);
    component.set("v.data", retailrows);
    component.set("v.olddata", retailrows);
    /*component.set("v.totalRecords", component.get("v.data").length);
                  component.set("v.startPage", 0);                
                component.set("v.endPage", pageSize - 1);
                var PagList = [];
                for ( var i=0; i< pageSize; i++ ) {
                    if ( component.get("v.data").length> i )
                        PagList.push(response.getReturnValue()[i]);    
                }
                component.set('v.PaginationList', PagList);
            } else {
                alert('ERROR');*/
}   
 
 });
$A.enqueueAction(action);

},   
    
    CellChange: function(component,event, helper){
        var atomicChange = event.getParam('draftValues')[0]; 
       var propertyNames = [];
        propertyNames = Object.getOwnPropertyNames(atomicChange);
        var currentPropertyUnderChange = '';
        var totalfcount = 0;
            var totalamounttopay = 0;
            var totalDAamounttopay = 0;
        for(var j = 0; j < propertyNames.length ; j++){
            if(propertyNames[j] != 'Id'){
                currentPropertyUnderChange = propertyNames[j];
            }
        }
        console.log('$$', atomicChange)
        //var restrictedFields = ['Director_Approved_Amount_to_Pay__c','Final_Amount_to_Pay__c'];
        //var allowedEditableFields = ['Final_Quantity__c'];
        var data = component.get('v.data');
        console.log('$$', data.length)
        for(var i = 0 ; i < data.length ; i++ ){               
                if(data[i].Id == atomicChange.Id){  
                	 data[i][currentPropertyUnderChange] = atomicChange[currentPropertyUnderChange];      
                      
                }
            
        }
        component.set('v.data', data);  
         for(var i = 0 ; i < data.length ; i++ ){  
          
                if(data[i].Final_Quantity__c!=null){
                    totalfcount += parseInt(data[i].Final_Quantity__c);
                }
                if(data[i].Final_Amount_to_Pay__c!=null){
                    totalamounttopay += parseInt(data[i].Final_Amount_to_Pay__c);
                }
                if(data[i].Director_Approved_Amount_to_Pay__c!=null){
                    totalDAamounttopay += parseInt(data[i].Director_Approved_Amount_to_Pay__c);
                }

        
         }
         component.set("v.totalCostFQ", totalfcount);
    component.set("v.totalCostFAP", totalamounttopay);
    component.set("v.totalCostDAAP",totalDAamounttopay);
        
    },
        
        approvetherecords: function(component,event, helper){
            var records = component.get("v.selectedpdrecords"); 
            var action = component.get("c.approvetheprogramdetails"); 
            
            action.setParams({"listofprograms" : records});
            
            action.setCallback(this, function(response) {
                var state = response.getState();
                if (state === "SUCCESS") {
                     component.set("v.SuccessTostMessage", true);
                    component.set("v.SuccessTostText", 'The records are approved successfully.');
                    this.getprogramsforretailaccount(component, event, helper);
                    setTimeout(function(){ component.set("v.SuccessTostMessage", false); }, 3000);
                }
                else if (state === "ERROR") {
                    // handle error
                    var errorMsg = '';
                    var errors = response.getError();
                    if (errors) {
                        if (errors[0] && errors[0].message) {
                            errorMsg = errors[0].message;
                        }
                        if (errors[0] && errors[0].pageErrors && errors[0].pageErrors[0].message) {
                            errorMsg += errors[0].pageErrors[0].message;
                        }
                    }
                }
            });
            component.set("v.selectedRows", []);       
            
            $A.enqueueAction(action);      
            
            
        },
            
            sortData : function(component,fieldName,sortDirection){
                var data = component.get("v.data");
                //function to return the value stored in the field
                var key = function(a) { return a[fieldName]; }
                var reverse = sortDirection == 'asc' ? 1: -1;
                
                // to handel number/currency type fields 
                if(fieldName == 'Estimated_Quantity__c' || 'Estimated_Amount_to_Pay__c' || 'Final_Quantity__c' || 'Final_Amount_to_Pay__c'){ 
                    data.sort(function(a,b){
                        var a = key(a) ? key(a) : '';
                        var b = key(b) ? key(b) : '';
                        return reverse * ((a>b) - (b>a));
                    }); 
                }
                else{// to handel text type fields 
                    data.sort(function(a,b){ 
                        var a = key(a) ? key(a).toLowerCase() : '';//To handle null values , uppercase records during sorting
                        var b = key(b) ? key(b).toLowerCase() : '';
                        return reverse * ((a>b) - (b>a));
                    });    
                }
                //set sorted data to accountData attribute
                component.set("v.data",data);
            },
                
                show: function(component,event){
                    component.set("v.toggleSpinner", true);     
                },
                    
                    hide: function(component,event){
                        component.set("v.toggleSpinner", false);     
                    }
})