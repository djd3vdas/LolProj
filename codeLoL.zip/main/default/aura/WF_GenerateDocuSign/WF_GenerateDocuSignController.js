( {
    	/*onLoad function to  redirect to DocuSign URL for e-signing process if "Plan Configuration status is Submitted" and
    	 "Atleast 1 File uploaded for Season Fields" otherwise throw corresponding errors
        */
        doInit : function(component, event, helper) {
            //call method of server side with parameter record id    
            let action=component.get("c.generateAgreement");
			//set parameter for the server class method
            action.setParams( {
                    recordId:component.get("v.recordId")
                }

            );

            // Add callback behavior for when response is received
            action.setCallback(this, function(response) {
                    var state=response.getState();
                    //alert(state);
                    var getReturnVal=response.getReturnValue();
                    var spinner=component.find("mySpinner");
                    $A.util.addClass(spinner, "slds-hide");

                    //alert(getReturnVal);
                    if (state==="SUCCESS") {
                        //alert("getReturnVal"+getReturnVal);
                        var toastEvent=$A.get("e.force:showToast");

                        if(getReturnVal=='NOTSUBMITTED') {

                            //Yes means InSeason Certificate has been e-signed by all parties
                            toastEvent.setParams( {
                                    "title": "Error!",
                                    "message": "Plan Configuration record is not yet Submitted. Kindly Submit it and try Generating the Agreement",
                                    "type":"error"
                                }

                            );
                            component.set('v.showModal', false);
                            toastEvent.fire();
                            var dismissActionPanel=$A.get("e.force:closeQuickAction");
                            dismissActionPanel.fire();
                        }

                        else if(getReturnVal=='FILENOTUPLOADED') {

                            //if No file Uploaded
                            toastEvent.setParams( {
                                    "title": "Error!",
                                    "message": "You have not uploaded any document while configuring a Plan, Please upload atleast one consolidated for all the season fields or one document per season field that you have selected in your Plan Configuration before generating the Agreement document",
                                    "type":"error",
                                    "duration": '10000'

                                }

                            );
                            component.set('v.showModal', false);
                            toastEvent.fire();
                            var dismissActionPanel=$A.get("e.force:closeQuickAction");
                            dismissActionPanel.fire();
                            component.set('v.showModal', true);
                        }

                        else if(getReturnVal=='EXCEPTION') {
                            //if exception occurs 
                            var toastEvent=$A.get("e.force:showToast");

                            toastEvent.setParams( {
                                    "title": "Error!",
                                    "message": "Unexpected Exception occured! Kindly reach out to System Administrator",
                                    "type":"error"
                                }

                            );
                            component.set('v.showSpinner', false);
                            toastEvent.fire();
                            $A.get("e.force:closeQuickAction").fire();
                            $A.get('e.force:refreshView').fire();
                        }

                        else {
                            //navigate to DocuSign for e-signing process
                            console.log("docusignpageUrl => ", getReturnVal);
                            var urlEvent=$A.get("e.force:navigateToURL");

                            urlEvent.setParams( {
                                    "url":getReturnVal
                                }

                            );
                            urlEvent.fire();
                        }
                    }

                }

            );
            // Send action off to be executed
            $A.enqueueAction(action);

        }

        ,
        showSpinner: function (component, event, helper) {
            var spinner=component.find("mySpinner");
            $A.util.removeClass(spinner, "slds-hide");
        }

        ,

        hideSpinner: function (component, event, helper) {
            var spinner=component.find("mySpinner");
            $A.util.addClass(spinner, "slds-hide");
        }

    }

)