({	//onload method to check if already InSeason Certificate has been generated or not
    
    doInit: function(component, event, helper) {
        var spinner = component.find("mySpinner");
        $A.util.removeClass(spinner, "slds-hide");
        var action = component.get("c.generateInSeasonCert");
        action.setParams({
            recordId: component.get("v.recordId") 
   		});
        // Add callback behavior for when response is received
        action.setCallback(this, function(response) {
            var state = response.getState();
            //alert(state);
            var getReturnVal=response.getReturnValue();
            var spinner = component.find("mySpinner");
            $A.util.addClass(spinner, "slds-hide");
              //alert(getReturnVal);
            if (state === "SUCCESS") {
                //alert("getReturnVal"+getReturnVal);
                var toastEvent = $A.get("e.force:showToast");
                if(getReturnVal=='Yes'){//Yes means InSeason Certificate has been e-signed by all parties
                    toastEvent.setParams({
                        "title": "Error!",
                        "message": "The Compliance Audit In-Season Certificate has already been generated. You cannot generate it again.",
                        "type":"error"
                    });
                     component.set('v.showModal',false);
                     toastEvent.fire();
                     var dismissActionPanel = $A.get("e.force:closeQuickAction");
                     dismissActionPanel.fire();
                }else if(getReturnVal='No'){ //No means Inseason Certificate is not signed yet by all parties
                        component.set('v.showModal',true);
                } else if(getReturnVal='Exception'){
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Error!",
                        "message": "Unexpected Exception occured! Kindly reach out to System Administrator",
                        "type":"error"
                    });
                    component.set('v.showSpinner',false);
                    toastEvent.fire();
                    $A.get("e.force:closeQuickAction").fire();
                    $A.get('e.force:refreshView').fire();
                }
            } else{
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "title": "Error!",
                    "message": "Unexpected Error occured! Kindly reach out to System Administrator",
                    "type":"error"
                });
                component.set('v.showSpinner',false);
                toastEvent.fire();
                $A.get("e.force:closeQuickAction").fire();
                $A.get('e.force:refreshView').fire();
            }
                        
        });
        // Send action off to be executed
        $A.enqueueAction(action);
    },
    //custom event handler to close the window
    closeMethodInAuraController : function(component, event, helper) {
		$A.get("e.force:closeQuickAction").fire();
	},
    //it shows spinner while waiting from server side to get response
    showSpinner: function (component, event, helper) {
        var spinner = component.find("mySpinner");
        $A.util.removeClass(spinner, "slds-hide");
    },
	//it hides spinner after server side call is complete
    hideSpinner: function (component, event, helper) {
        var spinner = component.find("mySpinner");
        $A.util.addClass(spinner, "slds-hide");
    }

})