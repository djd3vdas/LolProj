({
     handleSectionToggle: function (cmp, event) {
        var openSections = event.getParam('openSections');

        if (openSections.length === 0) {
            cmp.set('v.activeSectionsMessage', "All sections are closed");
        } else {
            cmp.set('v.activeSectionsMessage', "Open sections: " + openSections.join(', '));
        }
    },
    doInit : function(component, event, helper) {
        console.log('Inside the Objective Master doInit');
    },            
    
	  handleSectionToggle: function(cmp, event) {
        
        var openSections = event.getParam("openSections");
        
        if (openSections.length === 0) {
            cmp.set("v.activeSectionsMessage", "All sections are closed");
        } else {
            cmp.set("v.activeSectionsMessage",
                    "Open sections: " + openSections.join(", ")
                   );
        }
    },
    
	addobjectiverow : function(component, event, helper){
        component.getEvent("AddNewRowOSTEvt").setParams( {"ostsection" : 'objective', "parentExtId": '', "parentId": ''} ).fire();     
    },
    
    removeobjectiverow :function(component, event, helper){
        component.getEvent("DeleteRowOSTEvt").setParams( {"ostsection" : 'objective', "parentExtId": component.get("v.objective.Objective_External__c"), "parentId": component.get("v.objective.Id"), "id": component.get("v.objective.Id"), "indexVar" : component.get("v.rowIndex") }).fire();
    },
   
})