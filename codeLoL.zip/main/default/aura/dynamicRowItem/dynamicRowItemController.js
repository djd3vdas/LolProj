({
    
    
    doInit: function(component, event, helper){
    	//helper.fetchPickListVal(component);
        //helper.fetchpicklistvale(component, 'Entity__c', 'Entityvalue');
    },
    
    AddNewRow : function(component, event, helper){
       // fire the AddNewRowEvt Lightning Event 
       debugger;
        component.getEvent("AddRowEvt").fire();     
    },
    
      onValueSelect : function(component, event, helper){
        component.set('v.SwotInstance.Type__c', component.find('Typevalue').get('v.value'));
    },
    
    removeRow : function(component, event, helper){
        console.log("In dynamicRowItem v.rowIndex");
     // fire the DeleteRowEvt Lightning Event and pass the deleted Row Index to Event parameter/attribute
     	var section = component.get("v.section");
        console.log('In Row Item removeRow section:' + section);
        debugger;
        if("Swot" == section){
            console.log('In Row Item removeRow :' + component.get("v.SwotInstance.Id"));
        	component.getEvent("DeleteRowEvt").setParams({"indexVar" : component.get("v.rowIndex"), "SwotId": component.get("v.SwotInstance.Id") }).fire();    
        }else if("Strength" == section){
        	component.getEvent("DeleteRowEvt").setParams({"indexVar" : component.get("v.rowIndex"), "StrengthId": component.get("v.StrengthInstance.Id") }).fire();
        }else if("Weakness" == section){
            console.log('In Row Item removeRow :' + component.get("v.WeaknessInstance.Id"));
            component.getEvent("DeleteRowEvt").setParams({"indexVar" : component.get("v.rowIndex"), "WeaknessId": component.get("v.WeaknessInstance.Id") }).fire();
        }else if("Opportunity" == section){
            console.log('In Row Item removeRow :' + component.get("v.OpportunityInstance.Id"));
            component.getEvent("DeleteRowEvt").setParams({"indexVar" : component.get("v.rowIndex"), "OpportunityId": component.get("v.OpportunityInstance.Id") }).fire();
        }else if("Threat" == section){
            console.log('In Row Item removeRow :' + component.get("v.ThreatInstance.Id"));
            component.getEvent("DeleteRowEvt").setParams({"indexVar" : component.get("v.rowIndex"), "ThreatId": component.get("v.ThreatInstance.Id") }).fire();
        }else if("Critical Issue" == section){
            console.log('In Row Item removeRow :' + component.get("v.CriticalIssueInstance.Id"));
            component.getEvent("DeleteRowEvt").setParams({"indexVar" : component.get("v.rowIndex"), "CriticalIssueId": component.get("v.CriticalIssueInstance.Id") }).fire();
        }else if("Market Impact" == section){
            console.log('In Row Item removeRow :' + component.get("v.MarketImpactInstance.Id"));
            component.getEvent("DeleteRowEvt").setParams({"indexVar" : component.get("v.rowIndex"), "MarketImpactId": component.get("v.MarketImpactInstance.Id") }).fire();
        }else if("Desired Outcome" == section){
            console.log('In Row Item removeRow :' + component.get("v.DesiredOutcomeInstance.Id"));
            component.getEvent("DeleteRowEvt").setParams({"indexVar" : component.get("v.rowIndex"), "DesiredOutcomeId": component.get("v.DesiredOutcomeInstance.Id") }).fire();
        }else if("Objective" == section){
            console.log('In Row Item removeRow :' + component.get("v.ObjectiveInstance.Id"));
            component.getEvent("DeleteRowEvt").setParams({"indexVar" : component.get("v.rowIndex"), "ObjectiveId": component.get("v.ObjectiveInstance.Id") }).fire();
        }else if("Strategy" == section){
            console.log('In Strategy remove Row v.ObjectiveId :' + component.get("v.ObjectiveId"));  
            console.log('In Strategy remove Row v.StrategyInstance.Id :' + component.get("v.StrategyInstance.Id")); 
        }else if("Tactic" == section){
            console.log('In Tactic remove Row v.StrategyId :' + component.get("v.StrategyId"));  
            console.log('In Tactic remove Row v.TacticInstance.Id :' + component.get("v.TacticInstance.Id")); 
        } 
         
    }, 
  
})