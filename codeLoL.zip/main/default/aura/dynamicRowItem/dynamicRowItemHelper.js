({
	 fetchPickListVal: function(component) {
        
        var action = component.get("c.getselectOptions");
        action.setParams({
            objectName: component.get("v.objInfo"),
            selectedField: component.get("v.TfieldName")
        });
        
        
        action.setCallback(this, function(response) {
            if (response.getState() == "SUCCESS") {
                var list = response.getReturnValue();
                component.set("v.picklistValues", list);
             
                window.setTimeout(
                    $A.getCallback(function() {
                        component.find('Typevalue').set('v.value', component.get('v.SwotInstance.Type__c'));
                    }), 500
                );
            }else {
                console.log('Error'+state);
            }  
        });
        $A.enqueueAction(action);
    },
    
    
})