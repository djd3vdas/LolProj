({
   
	doOk: function(component, event, helper) {  
        var dismissActionPanel = $A.get("e.force:closeQuickAction");
         dismissActionPanel.fire();
         window.history.back();
    },
    doCancel: function(component, event, helper) {
         var dismissActionPanel = $A.get("e.force:closeQuickAction");
         dismissActionPanel.fire();
         window.history.back();
    }
})