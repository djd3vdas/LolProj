({
   
    
    doInit: function(component, event, helper) {
        //console.log('In DoInit');
        var action=component.get("c.disablePcNewButtonAccess");
        action.setCallback(this,function(response) {
        	var state = response.getState();
            if (state === "SUCCESS") {
                
                // from the server
                //alert("From server: " + response.getReturnValue());
                var message="You are logged in as  '"+response.getReturnValue()+"'. Please navigate to Retailer page to Configure New Plan.";
                 var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "title": "Error!",
                    "message":message,
                    "type":"error"
                });
                
                
                component.set('v.showSpinner',false);
                 var actionNavigate = component.get("c.getListViews");
    			actionNavigate.setCallback(this, function(response1){
                var state = response.getState();
                if (state === "SUCCESS") {
                   
                    var listviews = response1.getReturnValue();
                     //alert("From server 2: " + listviews);
                    var navEvent = $A.get("e.force:navigateToList");
                    navEvent.setParams({
                        "listViewId": listviews[0].Id,
                        "listViewName": null,
                        "scope": "Plan_Configuration__c"
                    });
                    toastEvent.fire();
                    navEvent.fire();
                    //window.history.back();
                 setTimeout(function() {
                location.reload();
            }, 4000);
                    
                }
            });
            $A.enqueueAction(actionNavigate);
            }else if (state === "ERROR") {
                var errors = response.getError();
                if (errors) {
                    toastEvent.setParams({
                    "title": "Error!",
                    "message":errors[0].message,
                    "type":"error"
                	});
                }
            } 
        });
          $A.enqueueAction(action);

        
    }
    
    
})