({

   	selectRecord : function(component, event, helper){      
    // User selected record
      var compEvent = component.getEvent("oSelectedRecordEvent");
        
      var selectedRecord = component.get("v.oRecord");
      var objectAPIName = component.get("v.objectAPIName");
      var optionType = component.get("v.optionType");
        
      		  console.log('optionType in lookup result: ' + optionType);
              console.log('objectAPIName in lookup result: ' + objectAPIName);
        	  console.log('selectedRecord in lookup result: ' + selectedRecord);
              console.log('selectedRecord.id in lookup result: ' + selectedRecord.Id);
        
    // set the Selected sObject Record to the event attribute.  
         compEvent.setParams({"recordByEvent" : selectedRecord });  
         compEvent.setParams({"objectAPIName" : objectAPIName });  
       	 compEvent.setParams({"optionType" : optionType });  
        
    // fire the event  
         compEvent.fire();
    },
})