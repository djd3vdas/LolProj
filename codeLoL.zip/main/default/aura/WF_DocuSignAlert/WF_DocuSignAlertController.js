({
	doInit : function(component, event, helper) {
        var pageReference = component.get("v.pageReference");

		component.set("v.fileuploadstatus", pageReference.state.fileuploadstatus);
       // alert(component.get("v.fileuploadstatus"));
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "title": "Error!",
                    "message": "Plan is already enrolled or not Submitted",
                     "type":"error"          
               });
                toastEvent.fire();
        window.history.back();
        setTimeout(function() {
  location.reload();
}, 3000);

    }
})