({
    /**
     * @name:    doInit
     * @description: This method is handler method of send email to retailer
     *      call on the time of component initial load.
     *      This method is responsible to fetch the existing record of plan configuration.
     **/
    doInit : function(component, event, helper) {
        var action = component.get("c.checkYieldReport");
        //alert('recordId:'+component.get("v.recordId"));
        action.setParams({"recordId": component.get("v.recordId")});
        
        action.setCallback(this, function(response){
            //<response.getState()> return response status as SUCCESS/ERROR etc.
            var state = response.getState();
            console.log("state="+state)
            console.log("response.getReturnValue:"+response.getReturnValue());
            //If response from server side is <SUCCESS>
            if (state === "SUCCESS" && response.getReturnValue()===true)
            {
                component.set("v.message","This action would share the Claim Status to Retailer in an Email. Would you like to proceed?");
            	component.set("v.saveEnable","true");
            }
            else
            {
                component.set("v.message","You have not initiated any Yield Report for the selected Plan Configuration. Please submit the Yield Report and generate an Email");
            }
        });
        
            
        $A.enqueueAction(action);
    },
    
    /**
     * @name:    doCancel      
     * @description: This method is responsible to cancel or close the modal window.
     **/
    doCancel : function(component, event, helper) {
        $A.get("e.force:closeQuickAction").fire();
        $A.get('e.force:refreshView').fire(); 
        setTimeout(function() {
            location.reload();
        }, 1000);
    },
    
    /**
     * @name:    doSave      
     * @description: This method is responsible to send email to retailer.
     **/
    doSave : function(component, event, helper) {
        /** Server side controller calling logic. **/
        
        var action = component.get("c.sendEmailRetailer");
        //alert('recordId:'+component.get("v.recordId"));
        action.setParams({"recordId": component.get("v.recordId")});
        
        action.setCallback(this, function(response){
            //<response.getState()> return response status as SUCCESS/ERROR etc.
            var state = response.getState();
            console.log("state="+state)
            console.log("response.getReturnValue:"+response.getReturnValue());
            
            //If response from server side is <SUCCESS>
            if (state === "SUCCESS" && response.getReturnValue()===true){
                var responseWCRecord = response.getReturnValue();
                
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "title": "Success!",
                    "message": "The Claim Status Email has been generated successfully."
                });
                toastEvent.fire();
                //Navigate to detail page.
                $A.get("e.force:closeQuickAction").fire();
                $A.get('e.force:refreshView').fire();                    
                
                
            }
            else if(response.getReturnValue()===false)
            {
                //Error message display logic.
                var errors = response.getError();
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "title": "ERROR!",
                    "message": 'No Yield Report found for this plan configuration!'
                });
                toastEvent.fire();
                //Navigate to detail page.
                $A.get("e.force:closeQuickAction").fire();
                $A.get('e.force:refreshView').fire();                    
                
            }
            
           });
        
        
        $A.enqueueAction(action);
    }
})