({
	doInit : function(component, event, helper) {
        alert("abc"+ component.get("v.recordId"));
         component.set('v.showMessage',true);
         $A.createComponent(
                "c:editPlanConfig",
                {
                    "recordId":  component.get("v.recordId")                     
                },
             
                function(popup, status, errorMessage){
                    if(status === 'SUCCESS') {
					var body = component.get("v.body");
                    body.push(popup);
                 console.log('body=== ',JSON.stringify(body));
                    component.set("v.body", body); 
                      /*  var modalPromise = component.find('overlayLib').showCustomModal({
                            body: popup,
                            showCloseButton: false
                        });*/
                    }else{
                        console.log('else body=== ',JSON.stringify(body));
                    }
                }
            );
    }
})