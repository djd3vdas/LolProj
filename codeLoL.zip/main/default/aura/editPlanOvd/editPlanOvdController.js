({
	doInit : function(component, event, helper) {
       // console.log('abc'+component.get("v.pageReference").state.recordId);
         //console.log('record id'+component.get("v.recordIdPlan"));
    }
})