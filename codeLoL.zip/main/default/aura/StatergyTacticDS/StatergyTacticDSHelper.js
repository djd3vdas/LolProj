({
    
  /*fetchPickListVal: function(component) {
		      
        var action = component.get("c.findPicklistOptions");
        action.setParams({
            objAPIName: component.get("v.objInfo"),
            fieldAPIname: component.get("v.BfieldName")
             
        });
        
        
        action.setCallback(this, function(response) {
            if (response.getState() == "SUCCESS") {
                var list = response.getReturnValue();
                component.set("v.picklistValues", list);
              
                  
            }else {
                console.log('Error'+state);
            }  
        });
        $A.enqueueAction(action);
    },*/
    
    
    
})