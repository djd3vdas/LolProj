({

    doInit:function(component, event, helper){
        console.log('In Strategy Init parentExtId: ' + component.get("v.parentExtId"));
        console.log('In Strategy Init parentId: ' + component.get("v.parentId"));
    },
    
	addstrategyrow : function(component, event, helper){
        component.getEvent("AddNewRowOSTEvt").setParams( {"ostsection" : "strategy", "parentExtId": component.get("v.parentExtId"), "parentId": component.get("v.parentId")} ).fire();     
    },
    
    removestrategyrow :function(component, event, helper){
        component.getEvent("DeleteRowOSTEvt").setParams( {"ostsection" : "strategy", "parentExtId": component.get("v.parentExtId"), "extid": component.get("v.strategy.Strategy_External__c"), "parentId": component.get("v.parentId"), "id": component.get("v.strategy.Id"), "indexVar" : component.get("v.rowIndex") }).fire();
    },
    
})