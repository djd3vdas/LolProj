({  
    
    fetchrecordtype : function(component, event, helper) {
        var action = component.get("c.getAccountrecordtype");
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var storeResponse = response.getReturnValue();
                
                // set searchResult list with return value from server.
                component.set("v.recordTypeId", storeResponse);
            }
            
        });
        $A.enqueueAction(action);	
    },
    
    fetchrecordtypeforGrowerDynamic : function(component, event, helper) {
        var action = component.get("c.getgdddrecordtype");
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var storeResponse = response.getReturnValue();
                
                // set searchResult list with return value from server.
                component.set("v.GDDRrecordTypeId", storeResponse);
            }
            
        });
        $A.enqueueAction(action);	
    },
    
    fetchrecordtypeforGrowerStatic : function(component, event, helper) {
        var action = component.get("c.getgsddrecordtype");
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var storeResponse = response.getReturnValue();
                
                // set searchResult list with return value from server.
                component.set("v.GSDDrecordTypeId", storeResponse);
            }
            
        });
        $A.enqueueAction(action);	
    },
    
    fetchrecordtypeforGrowerStaticDollar : function(component, event, helper) {
        var action = component.get("c.getgsdUDrecordtype");
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var storeResponse = response.getReturnValue();
                
                // set searchResult list with return value from server.
                component.set("v.GSDUDrecordTypeId", storeResponse);
            }
            
        });
        $A.enqueueAction(action);	
    },
    
    getprogramsforretailaccount : function(component,event, helper){
        component.set('v.columns', [
            {label: 'Creator', fieldName:'Created_Name__c', type:'text', editable: false, sortable: true},
            {label: 'Account', fieldName:'Account_Name__c', type:'text', editable: false, sortable: true},
            {label: 'Retailer Account', fieldName: 'Retailer_Account_Name__c', type: 'text', editable: false, typeAttributes: { required: true },sortable: true},
            {label: 'Program', fieldName: 'Program_Name__c', type: 'text', editable: false,  typeAttributes: { required: true },sortable: true },
            {label: 'Estimated Quantity', fieldName: 'Estimated_Quantity__c', type: 'number', editable: false, Position:'right',typeAttributes: { required: true }, sortable: true},
            {label: 'Estimated Amount to Pay', fieldName: 'Estimated_Amount_to_Pay__c', type: 'currency', editable: false, typeAttributes: { currencyCode: 'USD'},  typeAttributes: { required: true },sortable: true},
            {label: 'Final Quantity', fieldName: 'Final_Quantity__c', type: 'number', editable: true, typeAttributes: { required: true },  sortable: true, "cellAttributes": {"class": {"fieldName": "showClass"}  }},
            {label: 'Final Amount to Pay', fieldName: 'Final_Amount_to_Pay__c', type: 'currency', editable: true, typeAttributes: { currencyCode: 'USD'},  sortable: true, "cellAttributes": {"class": {"fieldName": "showClass"}  }}
        ]);    
       
        
        var action = component.get("c.getrecordsbyprogramname"); 
        var retailid = component.get("v.selectedRecordIdR");
        var accid = component.get("v.selectedRecordId");
        var tpbid = component.get("v.selectedRecordIdT");
        
        if(accid == '') accid = null;
        if(retailid == '') retailid = null;
        if(tpbid == '') tpbid = null;
        
        
        console.log(retailid);
        action.setParams({  retaileraccountid : retailid,
                          accountid : accid,
                          programname : tpbid,
                          
                         });
        
        action.setCallback(this,function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                
                var tempRows = JSON.parse(JSON.stringify(response.getReturnValue()));
                var retailrows = response.getReturnValue();
                //var pageSize = component.get("v.pageSize");
                var totalCount = 0;
                 var totalEstimatedquantity = 0;
                var totalEstimatedamount = 0;
                var totalfcount = 0;
                var totalamounttopay = 0;
                for (var i = 0; i < retailrows.length; i++) {
                    var retailrow = retailrows[i];
                    var tempRow = tempRows[i];
                    //if (retailrow.Account__c)retailrow.Account__c = retailrow.Account__r.Name;
                    //if (retailrow.Retailer_Account__c)retailrow.Retailer_Account__c = retailrow.Retailer_Account__r.Name;
                    if(retailrows[i].Estimated_Quantity__c!=null){
                        totalEstimatedquantity+=parseInt(retailrows[i].Estimated_Quantity__c);
                        totalCount+=parseInt(tempRows[i].Estimated_Quantity__c);
                    } 
                    if(retailrows[i].Estimated_Amount_to_Pay__c!=null){
                        totalEstimatedamount += (retailrows[i].Estimated_Amount_to_Pay__c);
                         totalCount+=parseInt(tempRows[i].Estimated_Amount_to_Pay__c);
                    }
                    if(retailrows[i].Final_Quantity__c!=null){
                        totalfcount += parseInt(retailrows[i].Final_Quantity__c);
                        totalCount+=parseInt(tempRows[i].Final_Quantity__c);
                    }
                    if(retailrows[i].Final_Amount_to_Pay__c!=null){
                        totalamounttopay += parseInt(retailrows[i].Final_Amount_to_Pay__c);
                         totalCount+=parseInt(tempRows[i].Final_Amount_to_Pay__c);
                    }
                  
                   
                    if(retailrows[i].RecordTypeId == '012540000017ceZAAQ'){
                            console.log('******Entered Here');
                            retailrows[i].showClass =  'hideEdit';
                        }
                     
                    
                } 
                
                component.set("v.totalCostEQ",totalEstimatedquantity);
                component.set("v.totalCostFQ", totalfcount);
                component.set("v.totalCostFAP", totalamounttopay);
                component.set("v.totalCostEAP",totalEstimatedamount);
               
                component.set("v.data", retailrows);
                component.set("v.olddata", tempRows);
                /*component.set("v.totalRecords", component.get("v.data").length);
                  component.set("v.startPage", 0);                
                component.set("v.endPage", pageSize - 1);
                var PagList = [];
                for ( var i=0; i< pageSize; i++ ) {
                    if ( component.get("v.data").length> i )
                        PagList.push(response.getReturnValue()[i]);    
                }
                component.set('v.PaginationList', PagList);
            } else {
                alert('ERROR');*/
                
            }   
            
        });
        $A.enqueueAction(action);
        
    }, 
    
    cellchange : function(component,event, helper){
        var atomicChange = event.getParam('draftValues')[0]; 
        var propertyNames = [];
        propertyNames = Object.getOwnPropertyNames(atomicChange);
        var currentPropertyUnderChange = '';
        for(var j = 0; j < propertyNames.length ; j++){
            if(propertyNames[j] != 'Id'){
                currentPropertyUnderChange = propertyNames[j];
            }
        }
        console.log('$$', atomicChange)
        var restrictedFields = ['Final_Amount_to_Pay__c'];
        var allowedEditableFields = ['Final_Quantity__c'];
        var data = component.get('v.data');
        console.log('$$', data.length)
          var totalEstimatedquantity = 0;
                var totalEstimatedamount = 0;
                var totalfcount = 0;
                var totalamounttopay = 0;
       
        for(var i = 0 ; i < data.length ; i++ ){           
            console.log(data[i].Id);
            if(data[i].Id == atomicChange.Id){
                console.log('rec', data[i].RecordTypeId);
                
                if(data[i].RecordTypeId == component.get("v.GSDDrecordTypeId") || data[i].RecordTypeId == component.get("v.GSDUDrecordTypeId")){
                   
                    if(restrictedFields.includes(currentPropertyUnderChange)){                        
                        data[i][currentPropertyUnderChange] = atomicChange[currentPropertyUnderChange];                         
                    } else if(allowedEditableFields.includes(currentPropertyUnderChange)){
                        data[i][currentPropertyUnderChange] = atomicChange[currentPropertyUnderChange]; 
							 data[i].UpdateFlag__c = true;
                    }    
                }else if(data[i].RecordTypeId == component.get("v.GDDRrecordTypeId")){
                    data[i][currentPropertyUnderChange] = atomicChange[currentPropertyUnderChange];
                    data[i].UpdateFlag__c = true;
                }
            }            
        }

        
              
        component.set('v.data', data);  
         for(var i = 0 ; i < data.length ; i++ ){  
            if(data[i].Estimated_Quantity__c!=null){
                        totalEstimatedquantity+=parseInt(data[i].Estimated_Quantity__c);
                        //totalCount+=parseInt(tempRows[i].Estimated_Quantity__c);
                    } 
                    if(data[i].Estimated_Amount_to_Pay__c!=null){
                        totalEstimatedamount += (data[i].Estimated_Amount_to_Pay__c);
                        // totalCount+=parseInt(tempRows[i].Estimated_Amount_to_Pay__c);
                    }
                    if(data[i].Final_Quantity__c!=null){
                        totalfcount += parseInt(data[i].Final_Quantity__c);
                        /*if(!isNaN(data[i].Final_Amount_to_Pay__c) && !isNaN(data[i].Program_Budget__r.Program__r.Discount_Value__c) ){
                             
                             data[i].Final_Amount_to_Pay__c = data[i].Final_Quantity__c * data[i].Program_Budget__r.Program__r.Discount_Value__c;
                            
                        }*/
                      
                    }
                    if(data[i].Final_Amount_to_Pay__c!=null){
                        totalamounttopay += parseInt(data[i].Final_Amount_to_Pay__c);
                        
                         //totalCount+=parseInt(tempRows[i].Final_Amount_to_Pay__c);
                    }
        }
         component.set("v.totalCostEQ",totalEstimatedquantity);
                component.set("v.totalCostFQ", totalfcount);
                component.set("v.totalCostFAP", totalamounttopay);
                component.set("v.totalCostEAP",totalEstimatedamount);
        
        /*var oldlist = component.get('v.olddata');
        var updatedlist = component.get('v.data');
        var isvalid = true;
        
        for(var i = 0 ; i < oldlist.length ; i++ ){
            for(var j = 0 ; j < updatedlist.length ; j++ ){
                //var string = updatedlist[j].id:'{{title :"adasd",messages:["dsfdsfsdf"],fieldNames:["Estimated_Amount_to_Pay__c","Final_Amount_to_Pay__c"]}'
                
                //errors.rows[updatedlist[j].Id] = {title :"adasd",messages:['dsfdsfsdf'],fieldNames:['Estimated_Amount_to_Pay__c','Final_Amount_to_Pay__c']};
                console.log(oldlist[i].Id);
                console.log(updatedlist[j].Id);
                if(oldlist[i].Id == updatedlist[j].Id){
                    if(updatedlist[j].RecordTypeId ==  component.get("v.GSDDrecordTypeId") || updatedlist[j].RecordTypeId == component.get("v.GSDUDrecordTypeId")){
                        if(updatedlist[j].Final_Amount_to_Pay__c != oldlist[i].Final_Amount_to_Pay__c){
                           
                           component.set("v.ErrorTostMessage", true); 
                            component.set("v.ErrorTostText", 'The recordtype of "Grower Static Dollar Detail" and "Grower Static Dollar per Unit Detail" cannot be Editable for Amount fields!');	
                            
                            updatedlist[j].showClass = "redcolor";
                            helper.getprogramsforretailaccount(component, event, helper);
                            updatedlist[j].showClass = 'redcolor';
                            setTimeout(function(){ component.set("v.ErrorTostMessage", false); }, 3000);
                            isvalid = false;
                        }    
                    }
                }
            }
        }
        
        if(isvalid){            
            var action = component.get("c.updateprogramdetails");
            action.setParams({"listTest" : updatedlist});
            action.setCallback(this, function(response) {
                var state = response.getState();
                if (state === "SUCCESS") {   
                    component.set("v.SuccessTostMessage", true);
                    component.set("v.SuccessTostText", 'The record got updated successfully');
                    helper.getprogramsforretailaccount (component, event, helper);  
                    setTimeout(function(){ component.set("v.SuccessTostMessage", false); }, 3000);
                }
                else if (state === "ERROR") {
                    // handle error
                    var errorMsg = '';
                    var errors = response.getError();
                    if (errors) {
                        if (errors[0] && errors[0].message) {
                            errorMsg = errors[0].message;
                        }
                        if (errors[0] && errors[0].pageErrors && errors[0].pageErrors[0].message) {
                            errorMsg += errors[0].pageErrors[0].message;
                        }
                    }
                }
            });
            $A.enqueueAction(action);    
        }*/
        
         
    },
    
    sortData : function(component,fieldName,sortDirection){
        var data = component.get("v.data");
        //function to return the value stored in the field
        var key = function(a) { return a[fieldName]; }
        var reverse = sortDirection == 'asc' ? 1: -1;
        
        // to handel number/currency type fields 
        if(fieldName == 'Estimated_Quantity__c' || 'Estimated_Amount_to_Pay__c' || 'Final_Quantity__c' || 'Final_Amount_to_Pay__c'){ 
            data.sort(function(a,b){
                var a = key(a) ? key(a) : '';
                var b = key(b) ? key(b) : '';
                return reverse * ((a>b) - (b>a));
            }); 
        }
        else{// to handel text type fields 
            data.sort(function(a,b){ 
                var a = key(a) ? key(a).toLowerCase() : '';//To handle null values , uppercase records during sorting
                var b = key(b) ? key(b).toLowerCase() : '';
                return reverse * ((a>b) - (b>a));
            });    
        }
        //set sorted data to accountData attribute
        component.set("v.data",data);
    },
    
    submittherecords :function(component, event, helper){
        var records = component.get("v.selectedpdrecords");
        //var selectedrecords = JSON.stringify(records);

        var action = component.get("c.submitforapproval");
        action.setParams({"listofprograms" : records});
        
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                //component.set("v.SuccessMessage", "Records are submitted for approval succesfully !");                 
                component.set("v.SuccessTostMessage", true);
                    component.set("v.SuccessTostText", 'The records submitted for Approval.');
                this.getprogramsforretailaccount(component, event, helper);
                setTimeout(function(){ component.set("v.SuccessTostMessage", false); }, 3000);	
            }
            else if (state === "ERROR") {
                // handle error
                var errorMsg = '';
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        errorMsg = errors[0].message;
                    }
                    if (errors[0] && errors[0].pageErrors && errors[0].pageErrors[0].message) {
                        errorMsg += errors[0].pageErrors[0].message;
                    }
                }
            }
        });
        component.set("v.selectedRows", []);       
        
        $A.enqueueAction(action);
        
    },
    
    canceltherecords:function(component, event, helper, olddata){
        component.set("v.SuccessMessage", "");      
        var dataset = component.get("v.olddata");
          
        component.set("v.data", dataset);    
    }
    
    
})