({
        doInit : function(component, event, helper){
        //helper.onloaddata(component, event, helper);      
        
        helper.fetchrecordtype(component, event, helper);
        helper.fetchrecordtypeforGrowerDynamic(component, event, helper);
        helper.fetchrecordtypeforGrowerStatic(component, event, helper);
        helper.fetchrecordtypeforGrowerStaticDollar(component, event, helper);        
        helper.getprogramsforretailaccount (component, event, helper);
    },
    
    handleFilterchange : function(component,event,helper) {
        console.log("You selected an account: " + component.get("v.selectedRecordId"));  
       		 helper.getprogramsforretailaccount(component, event, helper);
    },
    
    fetchprogramsRetailAccount  : function(component, event, helper){
        helper.getprogramsforretailaccount (component, event, helper);
        
    },
    
    fetchprogramsforAccount : function(component, event, helper){
        helper.getprogramsforretailaccount(component, event, helper);
        
    },
    
 fetchprogramsforProgram : function(component, event, helper){
     debugger;
        helper.getprogramsforretailaccount(component, event, helper);
        
    },
    
    handleSaveEdition: function (component, event, helper) {
        var draftValues = event.getParam('draftValues'); 
        
        var draftvaluesstr = JSON.stringify(draftValues);        
        console.log(draftvaluesstr);
        var action = component.get("c.updateprogramdetails");
        action.setParams({"listTest" : draftvaluesstr});
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                //helper.onloaddata(component, event, helper);
                helper.getprogramsforretailaccount (component, event, helper);
                //helper.getprogramsforaccount(component, event, helper);
                //helper.searchbasedonprogram(component, event, helper);
            }
            else if (state === "ERROR") {
                var errorMsg = '';
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        errorMsg = errors[0].message;
                    }
                    if (errors[0] && errors[0].pageErrors && errors[0].pageErrors[0].message) {
                        errorMsg += errors[0].pageErrors[0].message;
                    }
                }
            }
        });
        //this.fetchprogramsRetailAccount(component, event, helper);
        $A.enqueueAction(action);
        
    },
    
    handleSelect : function(component, event, helper) {
        console.log('rows data  after select ',JSON.stringify(component.get('v.data')));
        //helper.actiononselectedrecords(component, event, helper);  
        var selectedRows = event.getParam('selectedRows'); 
        console.log(selectedRows)
        var setRows = [];
        for ( var i = 0; i < selectedRows.length; i++ ) {            
            setRows.push(selectedRows[i]);
        }
        
        component.set("v.selectedpdrecords", setRows);   
    },
    
    approvalSubmit :function(component, event, helper){
        helper.submittherecords(component, event, helper);
        
    },   
    handlechange : function(component, event, helper) {
        
        helper.getprogramsforretailaccount (component, event, helper);
    },
    
    handleEditCellChange : function(component, event, helper) {
        helper.cellchange(component, event, helper); 
    },
    
    save : function(component, event, helper){  
        
        var oldlist = component.get('v.olddata');
        var updatedlist = component.get('v.data');
        var isvalid = true;
       /*  var errors = component.get("v.errors");
        if(errors==undefined || errors==null ){
            errors = { rows: {}, table: {} }
        } */
        for(var i = 0 ; i < oldlist.length ; i++ ){
            for(var j = 0 ; j < updatedlist.length ; j++ ){
                //var string = updatedlist[j].id:'{{title :"adasd",messages:["dsfdsfsdf"],fieldNames:["Estimated_Amount_to_Pay__c","Final_Amount_to_Pay__c"]}'
                
                //errors.rows[updatedlist[j].Id] = {title :"adasd",messages:['dsfdsfsdf'],fieldNames:['Estimated_Amount_to_Pay__c','Final_Amount_to_Pay__c']};
                console.log(oldlist[i].Id);
                console.log(updatedlist[j].Id);
                if(oldlist[i].Id == updatedlist[j].Id){
                    if(updatedlist[j].RecordTypeId ==  component.get("v.GSDDrecordTypeId") || updatedlist[j].RecordTypeId == component.get("v.GSDUDrecordTypeId")){
                        if(updatedlist[j].Final_Amount_to_Pay__c != oldlist[i].Final_Amount_to_Pay__c){
                           
                           component.set("v.ErrorTostMessage", true); 
                            component.set("v.ErrorTostText", 'The recordtype of "Grower Static Dollar Detail" and "Grower Static Dollar per Unit Detail" cannot be Editable for Amount fields!');	
                            
                            updatedlist[j].showClass = "redcolor";
                            helper.getprogramsforretailaccount(component, event, helper);
                            updatedlist[j].showClass = 'redcolor';
                            setTimeout(function(){ component.set("v.ErrorTostMessage", false); }, 2500);
                            isvalid = false;
                        }    
                    }
                }
            }
        }
        
        if(isvalid){            
            var action = component.get("c.updateprogramdetails");
            action.setParams({"listTest" : updatedlist});
            action.setCallback(this, function(response) {
                var state = response.getState();
                if (state === "SUCCESS") {   
                    component.set("v.SuccessTostMessage", true);
                    component.set("v.SuccessTostText", 'The record got updated successfully');
                    helper.getprogramsforretailaccount (component, event, helper);  
                    setTimeout(function(){ component.set("v.SuccessTostMessage", false); }, 3000);
                }
                else if (state === "ERROR") {
                    // handle error
                    var errorMsg = '';
                    var errors = response.getError();
                    if (errors) {
                        if (errors[0] && errors[0].message) {
                            errorMsg = errors[0].message;
                        }
                        if (errors[0] && errors[0].pageErrors && errors[0].pageErrors[0].message) {
                            errorMsg += errors[0].pageErrors[0].message;
                        }
                    }
                }
            });
            $A.enqueueAction(action);    
        }
        
        
    },
    
    updateColumnSorting: function (component, event, helper) {
        var sortBy  = event.getParam('fieldName');
        var sortDirection = event.getParam('sortDirection');
        // assign the latest attribute with the sorted column fieldName and sorted direction
        component.set("v.sortBy", sortBy);
        component.set("v.sortDirection", sortDirection);
        helper.sortData(component, sortBy, sortDirection);
        
    },
    
    next : function(component, event){
        var sObjectList = component.get("v.data");
        var end = component.get("v.endPage");
        var start = component.get("v.startPage");
        var pageSize = component.get("v.pageSize");
        var Paginationlist = [];
        var counter = 0;
        for(var i=end+1; i<end+pageSize+1; i++){
            if(sObjectList.length > i){
                Paginationlist.push(sObjectList[i]);
            }
            counter ++ ;
        }
        start = start + counter;
        end = end + counter;
        component.set("v.startPage",start);
        component.set("v.endPage",end);
        component.set('v.PaginationList', Paginationlist);
    },
    previous : function(component, event){
        var sObjectList = component.get("v.data");
        var end = component.get("v.endPage");
        var start = component.get("v.startPage");
        var pageSize = component.get("v.pageSize");
        var Paginationlist = [];
        var counter = 0;
        for(var i= start-pageSize; i < start ; i++){
            if(i > -1){
                Paginationlist.push(sObjectList[i]);
                counter ++;
            }else{
                start++;
            }
        }
        start = start - counter;
        end = end - counter;
        component.set("v.startPage",start);
        component.set("v.endPage",end);
        component.set('v.PaginationList', Paginationlist);	
    },
    
    unselectrecords : function(component, event, helper) {
        
        component.set("v.selectedRows", []);	
        //component.set("v.selectedpdrecords", setRows); 
        component.set("v.ErrorTostMessage", false);
        
        //helper.getprogramsforretailaccount (component, event, helper); 
        
    },
})