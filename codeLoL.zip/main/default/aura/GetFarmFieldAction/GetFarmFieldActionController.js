({
	doInit : function(component, event, helper) {
        component.set('v.showMessage',true);
        var action = component.get('c.getRecords');
        action.setParams({
            recordId: component.get("v.recordId")
        });
        
        
        action.setCallback(this, function (response) 
        {
            //var state = response.getState();
            var result = response.getReturnValue();
            //console.log('hello:'+result);
            if (result == false) 
            {
                            var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "title": "Warning!",
                    "message": "Farms,Fields and Season Fields have already been fetched!"
                });
                component.set('v.showMessage',false);
                toastEvent.fire();
                
                $A.get("e.force:closeQuickAction").fire();
                $A.get('e.force:refreshView').fire();
               //component.set('v.showMessage','Farms,Fields and Season Fields data is already fetched!'); 
            } 
            else
            {
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "title": "Success!",
                    "message": "It takes few moments."
                });
                component.set('v.showMessage',false);
                toastEvent.fire();
                //component.set('v.showMessage','Getting Farms,Fields and Season Fields..Whenever it will done Fetched Record field will be marked as checked!'); 
                $A.get("e.force:closeQuickAction").fire();
                $A.get('e.force:refreshView').fire();
            }
        
        });
        $A.enqueueAction(action);
    }
})