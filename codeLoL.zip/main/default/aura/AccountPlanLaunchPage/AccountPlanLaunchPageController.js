({
    doInit: function(component, event, helper) {
        var accountPlanId = component.get("v.recordId");
        console.log("Arun accountPlanId: " + accountPlanId);
        var reln = "Account_Plan__c = " + "'" + accountPlanId + "'";
        var andFilter = reln;
        component.set("v.andFilters", andFilter);

        // Query AP & new field
        // 1) If IsObjectiveTab = false => Set Discovery Tab as default
        // 2) If IsObjectiveTab = true => Set Objective Tab as default
        var action = component.get("c.getAccountPlan");
        
        action.setParams({
            "accountPlanId": component.get("v.recordId"),            
        })
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                component.set("v.Accountplan", response.getReturnValue());
                if(response.getReturnValue().IsObjectiveTab__c == false){
                    component.set("v.SelectedTabId","Discoverytab")
                }else{
                    component.set("v.SelectedTabId","Objectivestab")
                }
            }else{
                console.log('Save CriticalIssue Error !! ' + state);
            }
        });
        $A.enqueueAction(action);  
    },
    
	   DhandleActive : function(component, event, helper){
        
        var action = component.get("c.assigntab");
        action.setParams({
            "accountPlanId": component.get("v.recordId"),
            "selectedtab": component.get("v.Discoverytab")
        })
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
            }else{
                console.log('Save CriticalIssue Error !! ' + state);
            }
        });
        $A.enqueueAction(action);  
    },
    
    OhandleActive : function(component, event, helper){
        
        var action = component.get("c.assigntab");
        action.setParams({
            "accountPlanId": component.get("v.recordId"),
            "selectedtab": component.get("v.Mastertab")
        })
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
            }else{
                console.log('Save CriticalIssue Error !! ' + state);
            }
        });
        $A.enqueueAction(action);  
    },
    
    handleSectionToggle: function(cmp, event) {
        //debugger;
        var openSections = event.getParam("openSections");
        
        if (openSections.length === 0) {
            cmp.set("v.activeSectionsMessage", "All sections are closed");
        } else {
            cmp.set("v.activeSectionsMessage",
                    "Open sections: " + openSections.join(", ")
                   );
        }
    },
    
    toggleViewEdit: function(component, event, helper) {  
        debugger;
        if('Cancel' == event.getSource().get("v.label")){
            component.set("v.viewEditFlag", "Cancel");
            component.set("v.disableViewBtn", true);
            component.set("v.disableEditBtn", false);
            component.set("v.ShowMessage", false);
        }else {
            component.set("v.ShowMessage", false);
            component.set("v.viewEditFlag", "edit");
            component.set("v.disableViewBtn", false);
            component.set("v.disableEditBtn", true);
            
        }
    },
    
    Save :function(component, event, helper) { 
       // debugger;
        var appEvent = $A.get("e.c:AccountPlanSave");
        appEvent.setParams({
            "SaveFlag" : true });
        appEvent.fire();
            component.set("v.viewEditFlag", "Cancel");
            component.set("v.disableViewBtn", true);
            component.set("v.disableEditBtn", false);
            component.set("v.ShowMessage", false);
        
    },
    
    discoveryPdfGenerator: function (component, event, helper) {
        var recordId = component.get("v.recordId");
      window.setTimeout(
      $A.getCallback(function() {
        		// visualforce page URL
        		//window.location="/apex/AccountPlanDiscoveryPdf?id="+recordId + "Target=_blank";
          
          	     window.open(
                      '/apex/AccountPlanDiscoveryPdf?id='+recordId,
                      '_blank' 
                  );
    		 }), 1000
  		);
 }, 
    
});