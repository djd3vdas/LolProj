({
    
    getSwotList : function(component) {
    	var action = component.get("c.getSwotList");
             action.setParams({"accountPlanId": component.get("v.recordId")});
             action.setCallback(this, function(resp) {
                 component.set("v.SwotList", resp.getReturnValue());
                 if(resp.getReturnValue().length == 0){
                	this.createObjectData(component);
                 }
            });
            $A.enqueueAction(action);
    
	},

   /* getStrengthList : function(component) {
             //console.log('Inside getStrengthList');
             var action = component.get("c.getStrengthList");
             action.setParams({"accountPlanId": component.get("v.recordId")});
             action.setCallback(this, function(resp) {
                 component.set("v.StrengthList", resp.getReturnValue());
                 if(resp.getReturnValue().length == 0){
                	this.createObjectData(component);
                 }
            });
            $A.enqueueAction(action);
        },
     getWeaknessList : function(component) {
             //console.log('Inside getWeaknessList');
             var action = component.get("c.getWeaknessList");
             action.setParams({"accountPlanId": component.get("v.recordId")});
             action.setCallback(this, function(resp) {
                 component.set("v.WeaknessList", resp.getReturnValue());
                 console.log('callback getWeaknessList Weaknesslist: '+ resp.getReturnValue());
                 if(resp.getReturnValue().length == 0){
                     console.log('getWeaknessList inside row returned zero'); 
                	this.createObjectData(component);
                 }
            });
            $A.enqueueAction(action);
        },
     getOpportunityList : function(component) {
         var self = this;
             var action = component.get("c.getOpportunityList");
             action.setParams({"accountPlanId": component.get("v.recordId")});
             action.setCallback(this, function(resp) {
                 component.set("v.OpportunityList", resp.getReturnValue());
                 if(resp.getReturnValue().length == 0){
                	this.createObjectData(component);
                	console.log('called create Opportunity data event');
                 }
            });
            $A.enqueueAction(action);
        },
     getThreatList : function(component) {
             var action = component.get("c.getThreatList");//get data from controller
             action.setParams({"accountPlanId": component.get("v.recordId")});
             action.setCallback(this, function(resp) {
                 component.set("v.ThreatList", resp.getReturnValue());//set data in the page variable
                 console.log('callback getThreatList Threatlist: '+ resp.getReturnValue());
                 if(resp.getReturnValue().length == 0){
                	this.createObjectData(component);
                 }
            });
            $A.enqueueAction(action);
        },*/
     getCriticalIssueList : function(component) {
             var action = component.get("c.getCriticalIssueList");//get data from controller
             action.setParams({"accountPlanId": component.get("v.recordId")});
             action.setCallback(this, function(resp) {
                 component.set("v.CriticalIssueList", resp.getReturnValue());//set data in the page variable
                 if(resp.getReturnValue().length == 0){
                	this.createObjectData(component);
                 }
            });
            $A.enqueueAction(action);
        },
     getMarketImpactList : function(component) {
             var action = component.get("c.getMarketImpactList");//get data from controller
             action.setParams({"accountPlanId": component.get("v.recordId")});
             action.setCallback(this, function(resp) {
                 component.set("v.MarketImpactList", resp.getReturnValue());//set data in the page variable
                 if(resp.getReturnValue().length == 0){
                	this.createObjectData(component);
                 }
            });
            $A.enqueueAction(action);
        },
     getDesiredOutcomeList : function(component) {
             var action = component.get("c.getDesiredOutcomeList");//get data from controller
             action.setParams({"accountPlanId": component.get("v.recordId")});
             action.setCallback(this, function(resp) {
                 component.set("v.DesiredOutcomeList", resp.getReturnValue());//set data in the page variable
                 if(resp.getReturnValue().length == 0){
                	this.createObjectData(component);
                 }
            });
            $A.enqueueAction(action);
        },
 
    // get the objectList from component and add(push) New Object to List
    createObjectData: function(component, event) {
        console.log('in createObjectData');

        var selection = component.get("v.section");
        
        console.log('in createObjectData selection: ' + selection);
        
        if('Swot' == selection){
        	 console.log('create object data Swot')
            var rowItemsList = component.get("v.SwotList");
            if(rowItemsList.length == 0){
                rowItemsList.push({sobjectType: 'Account_Plan_SWOT__c', Type__c: '', Description__c: '', Entity__c:''});   
                component.set("v.SwotList", rowItemsList);
                           
            } 
        }else if('Critical Issue' == selection){
            var rowItemsList = component.get("v.CriticalIssueList");
            if(rowItemsList.length == 0){
	            rowItemsList.push({sobjectType: 'Account_Plan_Critical_Issue__c', Critical_Issue_Type__c: '', Critical_Issue_Description__c: '' });   
    		    component.set("v.CriticalIssueList", rowItemsList);
            }
        }else if('Market Impact' == selection){
            var rowItemsList = component.get("v.MarketImpactList");
            if(rowItemsList.length == 0){
        	    rowItemsList.push({sobjectType: 'Account_Plan_Market_Impact__c', Market_Impact_Type__c: '', Market_Impact_Description__c: '' });   
		        component.set("v.MarketImpactList", rowItemsList);
            }
        }else if('Desired Outcome' == selection){
            var rowItemsList = component.get("v.DesiredOutcomeList");
            if(rowItemsList.length == 0){
            	rowItemsList.push({sobjectType: 'Account_Plan_Desired_Outcome__c', Desired_Outcome_Type__c: '', Desired_Outcome_Description__c: '' });   
		        component.set("v.DesiredOutcomeList", rowItemsList);
            }
        }
    },

	//separate method to avoid dups of empty rows during initial load.    
    // get the objectList from component and add(push) New Object to List
    createObjectDataonAdd: function(component) {
        var selection = component.get("v.section");
        
        console.log('in createObjectData selection: ' + selection);
        
         if('Swot' == selection){
        	 console.log('create object data Swot')
            var rowItemsList = component.get("v.SwotList");                      
                rowItemsList.push({sobjectType: 'Account_Plan_SWOT__c', Type__c: '', Description__c: '', Entity__c:''});   
                component.set("v.SwotList", rowItemsList);            
        }else if('Critical Issue' == selection){
            console.log('create object data CriticalIssue')            
            var rowItemsList = component.get("v.CriticalIssueList");
	            rowItemsList.push({sobjectType: 'Account_Plan_Critical_Issue__c', Critical_Issue_Type__c: '', Critical_Issue_Description__c: '' });   
    		    component.set("v.CriticalIssueList", rowItemsList);
        }else if('Market Impact' == selection){
            console.log('create object data MarketImpact')            
            var rowItemsList = component.get("v.MarketImpactList");
        	    rowItemsList.push({sobjectType: 'Account_Plan_Market_Impact__c', Market_Impact_Type__c: '', Market_Impact_Description__c: '' });   
		        component.set("v.MarketImpactList", rowItemsList);
        }else if('Desired Outcome' == selection){
            console.log('create object data DesiredOutcome')            
            var rowItemsList = component.get("v.DesiredOutcomeList");
            	rowItemsList.push({sobjectType: 'Account_Plan_Desired_Outcome__c', Desired_Outcome_Type__c: '', Desired_Outcome_Description__c: '' });   
		        component.set("v.DesiredOutcomeList", rowItemsList);
        }
    },
    // helper function for check if first Name is not null/blank on save  
    /*validateRequired: function(component, event) {
        var isValid = true;
        var allRows = null;
        var section = component.get("v.section");
        
        if('Strength' == section){
            console.log('Inside Strength');
            allRows = component.get("v.StrengthList");
           	console.log('Inside Strength allRows' + allRows.length);
            for (var indexVar = 0; indexVar < allRows.length; indexVar++) {
                console.log('Inside Strength allRows type id: ' + indexVar + ' '+
                            allRows[indexVar].Strength_Description__c);
            if (allRows[indexVar].Strength_Description__c == '' || allRows[indexVar].Strength_Description__c == null) {
                isValid = false;
                alert('Strength Type Can\'t be Blank on Row Number ' + (indexVar + 1));
            	}
            }

        }else if ('Weakness' == section){
            console.log('Inside Weakness');
            allRows = component.get("v.WeaknessList");
           	console.log('Inside Weakness allRows' + allRows.length);
            for (var indexVar = 0; indexVar < allRows.length; indexVar++) {
                console.log('Inside Weakness allRows type id: ' + indexVar + ' '+
                            allRows[indexVar].Weakness_Description__c);
            if (allRows[indexVar].Weakness_Description__c == null || allRows[indexVar].Weakness_Description__c == '') {
                isValid = false;
                alert('Weakness Type Can\'t be Blank on Row Number ' + (indexVar + 1));
            	}
            }
        }else if ('Opportunity' == section){
            console.log('Inside Opportunity');
            allRows = component.get("v.OpportunityList");
           	console.log('Inside Opportunity allRows' + allRows.length);
            for (var indexVar = 0; indexVar < allRows.length; indexVar++) {
                console.log('Inside Opportunity allRows type id: ' + indexVar + ' '+ allRows[indexVar].Opportunity_Description__c);
            if (allRows[indexVar].Opportunity_Description__c == null || allRows[indexVar].Opportunity_Description__c == '') {
                isValid = false;
                alert('Opportunity Type Can\'t be Blank on Row Number ' + (indexVar + 1));
            }
            }
        }else if ('Threat' == section){
            console.log('Inside Threat');
            allRows = component.get("v.ThreatList");
           	console.log('Inside Threat allRows' + allRows.length);
            for (var indexVar = 0; indexVar < allRows.length; indexVar++) {
                console.log('Inside Threat allRows type id: ' + indexVar + ' '+
                            allRows[indexVar].Threat_Description__c);
            if (allRows[indexVar].Threat_Description__c == null || allRows[indexVar].Threat_Description__c == '') {
                isValid = false;
                alert('Threat Type Can\'t be Blank on Row Number ' + (indexVar + 1));
            }
            }
        }else if ('Critical Issue' == section){
            console.log('Inside CriticalIssue');
            allRows = component.get("v.CriticalIssueList");
           	console.log('Inside CriticalIssue allRows' + allRows.length);
            for (var indexVar = 0; indexVar < allRows.length; indexVar++) {
                console.log('Inside CriticalIssue allRows type id: ' + indexVar + ' '+
                            allRows[indexVar].CriticalIssue_Description__c);
            if (allRows[indexVar].Critical_Issue_Description__c == null || allRows[indexVar].Critical_Issue_Description__c == '') {
                isValid = false;
                alert('CriticalIssue Description Can\'t be Blank on Row Number ' + (indexVar + 1));
            }
            }
        }else if ('Market Impact' == section){
            console.log('Inside MarketImpact');
            allRows = component.get("v.MarketImpactList");
           	console.log('Inside MarketImpact allRows' + allRows.length);
            for (var indexVar = 0; indexVar < allRows.length; indexVar++) {
                console.log('Inside MarketImpact allRows type id: ' + indexVar + ' '+
                            allRows[indexVar].Market_Impact_Description__c);
            if (allRows[indexVar].Market_Impact_Description__c == null || allRows[indexVar].Market_Impact_Description__c == '') {
                isValid = false;
                alert('MarketImpact Description Can\'t be Blank on Row Number ' + (indexVar + 1));
            }
            }
        }else if ('Desired Outcome' == section){
            console.log('Inside DesiredOutcome');
            allRows = component.get("v.DesiredOutcomeList");
           	console.log('Inside DesiredOutcome allRows' + allRows.length);
            for (var indexVar = 0; indexVar < allRows.length; indexVar++) {
                console.log('Inside Desired_Outcome allRows type id: ' + indexVar + ' '+
                            allRows[indexVar].Desired_Outcome_Description__c);
            if (allRows[indexVar].Desired_Outcome_Description__c == null || allRows[indexVar].Desired_Outcome_Description__c == '') {
                isValid = false;
                alert('DesiredOutcome Description Can\'t be Blank on Row Number ' + (indexVar + 1));
                
            }
            }
        }
            return isValid;
        
       
    },*/
    
    
     // Swot function for delete the row
    reomveSwotRow: function(component, event, helper){
                debugger;
    	 console.log('dynRow removeDeletedRow Swot');
            component.set("v.notifMsgDelSwot", "");        
        	component.set("v.notifMsgSwot", ""); 
        
   
            // get the selected row Index for delete, from Lightning Event Attribute  
            var index = event.getParam("indexVar");
            var SwotId = event.getParam("SwotId");
            console.log('dynRow removeDeletedRow index: ' + index );
            console.log('removal ' + "{!v.section}" +'SwotId: ' + SwotId);
        
        if(SwotId != null){
			    var action = component.get("c.removeAccountswotPlans");
                action.setParams({"accountPlanObjList": component.get("v.SwotList"), "accountPlanId": component.get("v.recordId"), "apObjid": SwotId});
                action.setCallback(this, function(response) {
                    var state = response.getState();
                    if (state === "SUCCESS") {
                        console.log('return value: ' + response.getReturnValue());
                        component.set("v.SwotList", response.getReturnValue());
                        component.set("v.notifMsgDelSwot", "Removed Swot Successfully!");
                        if(component.get("v.SwotList").length == 0){
                            this.createObjectData(component);//leave atleast a row.
                        }
                    }
                });
                $A.enqueueAction(action);
            }else{
                    console.log('dynRow removeDeletedRow Strength List index: ' + index);
                    var allRowsList = component.get("v.SwotList");
                if(allRowsList.length == 1){
                 	   alert('This is a place holder row, which cannot be deleted!');
                }else{
                    allRowsList.splice(index, 1);
                    component.set("v.SwotList", allRowsList); // set the objList after remove selected row element  
                }

            }
        
    },
    
    // strength function for delete the row 
   /* removeStrengthRow: function(component, event, helper) {
            console.log('dynRow removeDeletedRow Strength');
            component.set("v.notifMsgDelStrength", "");        
        	component.set("v.notifMsgStrength", "");        
        
            //component.set("v.notifyMeDelStrength", "false");
            // get the selected row Index for delete, from Lightning Event Attribute  
            var index = event.getParam("indexVar");
            var StrengthId = event.getParam("StrengthId");
            console.log('dynRow removeDeletedRow index: ' + index );
            console.log('removal ' + "{!v.section}" +'StrengthId: ' + StrengthId);
            
        	if(StrengthId != null){
			    var action = component.get("c.removeAccountPlans");
                action.setParams({"accountPlanObjList": component.get("v.StrengthList"), "accountPlanId": component.get("v.recordId"), "apObjid": StrengthId});
                action.setCallback(this, function(response) {
                    var state = response.getState();
                    if (state === "SUCCESS") {
                        console.log('return value: ' + response.getReturnValue());
                        component.set("v.StrengthList", response.getReturnValue());
                        component.set("v.notifMsgDelStrength", "Removed Strength Successfully!");
                        if(component.get("v.StrengthList").length == 0){
                            this.createObjectData(component);//leave atleast a row.
                        }
                    }
                });
                $A.enqueueAction(action);
            }else{
                    console.log('dynRow removeDeletedRow Strength List index: ' + index);
                    var allRowsList = component.get("v.StrengthList");
                if(allRowsList.length == 1){
                 	   alert('This is a place holder row, which cannot be deleted!');
                }else{
                    allRowsList.splice(index, 1);
                    component.set("v.StrengthList", allRowsList); // set the objList after remove selected row element  
                }

            }
},

    // Weakness function for delete the row 
    removeWeaknessRow: function(component, event, helper) {
            console.log('dynRow removeDeletedRow Weakness');
            component.set("v.notifMsgDelWeakness", "");        
        	component.set("v.notifMsgWeakness", ""); 

        	var index = event.getParam("indexVar");
            var WeaknessId = event.getParam("WeaknessId");
            var section = component.get("v.section");
            
        	console.log('dynRow removeDeletedRow index: ' + index + 'WeaknessId: ' + WeaknessId);

        	if(WeaknessId != null){
			    var action = component.get("c.removeAccountPlans");
                action.setParams({"accountPlanObjList": component.get("v.WeaknessList"), "accountPlanId": component.get("v.recordId"), "apObjid": WeaknessId});
                action.setCallback(this, function(response) {
                    var state = response.getState();
                    if (state === "SUCCESS") {
                        console.log('return value: ' + response.getReturnValue());
                        component.set("v.WeaknessList", response.getReturnValue());//set data in the page variable
                        component.set("v.notifMsgDelWeakness", "Removed Weakness Successfully!");
                        if(component.get("v.WeaknessList").length == 0){
                            this.createObjectData(component);//leave atleast a row.
                        }                        
                    }
                });
                $A.enqueueAction(action);
            }else{
                    console.log('Removing added row weaknessList index: ' + index);
                    allRowsList = component.get("v.WeaknessList");
                if(allRowsList.length == 1){
                 	   alert('This is a place holder row, which cannot be deleted!');
                }else{                
                    allRowsList.splice(index, 1);
                    component.set("v.WeaknessList", allRowsList); // set the objList after remove selected row element  
                }
            }
},
    
    // Opportunity function for delete the row 
    removeOpportunityRow: function(component, event, helper) {
            console.log('dynRow removeDeletedRow Opportunity');
            component.set("v.notifMsgDelOpportunity", "");        
        	component.set("v.notifMsgOpportunity", ""); 
        
            // get the selected row Index for delete, from Lightning Event Attribute  
            var index = event.getParam("indexVar");
            var OpportunityId = event.getParam("OpportunityId");
            console.log('dynRow removeDeletedRow index: ' + index );
            console.log('removal ' + "{!v.section}" +'OpportunityId: ' + OpportunityId);
            
        	if(OpportunityId != null){
			    var action = component.get("c.removeAccountPlans");
                action.setParams({"accountPlanObjList": component.get("v.OpportunityList"), "accountPlanId": component.get("v.recordId"), "apObjid": OpportunityId});
                action.setCallback(this, function(response) {
                    var state = response.getState();
                    if (state === "SUCCESS") {
                        console.log('return value: ' + response.getReturnValue());
                        component.set("v.OpportunityList", response.getReturnValue());//set data in the page variable
                        component.set("v.notifMsgDelOpportunity", "Removed Opportunity Successfully!");
                        if(component.get("v.WeaknessList").length == 0){
                            this.createObjectData(component);//leave atleast a row.
                        }                         
                    }
                });
                $A.enqueueAction(action);
            }else{
                    console.log('dynRow removeDeletedRow Opportunity List index: ' + index);
                    var allRowsList = component.get("v.OpportunityList");
                if(allRowsList.length == 1){
                 	   alert('This is a place holder row, which cannot be deleted!');
                }else{                
                    allRowsList.splice(index, 1);
                    component.set("v.OpportunityList", allRowsList); // set the objList after remove selected row element  
                }
            }
},

    // Threat function for delete the row 
    removeThreatRow: function(component, event, helper) {
            console.log('dynRow removeDeletedRow Threat');
            component.set("v.notifMsgDelThreat", "");        
        	component.set("v.notifMsgThreat", ""); 
            // get the selected row Index for delete, from Lightning Event Attribute  
            var index = event.getParam("indexVar");
            var ThreatId = event.getParam("ThreatId");
            console.log('dynRow removeDeletedRow index: ' + index );
            console.log('removal ' + "{!v.section}" +'ThreatId: ' + ThreatId);
            
        	if(ThreatId != null){
			    var action = component.get("c.removeAccountPlans");
                action.setParams({"accountPlanObjList": component.get("v.ThreatList"), "accountPlanId": component.get("v.recordId"), "apObjid": ThreatId});
                action.setCallback(this, function(response) {
                    var state = response.getState();
                    if (state === "SUCCESS") {
                        console.log('return value: ' + response.getReturnValue());
                        component.set("v.ThreatList", response.getReturnValue());//set data in the page variable
                        component.set("v.notifMsgDelThreat", "Removed Threat Successfully!");
                        if(component.get("v.ThreatList").length == 0){
                            this.createObjectData(component);//leave atleast a row.
                        }                         
                        
                    }
                });
                $A.enqueueAction(action);
            }else{
                    console.log('dynRow removeDeletedRow Threat List index: ' + index);
                    var allRowsList = component.get("v.ThreatList");
                if(allRowsList.length == 1){
                 	   alert('This is a place holder row, which cannot be deleted!');
                }else{                
                    allRowsList.splice(index, 1);
                    component.set("v.ThreatList", allRowsList); // set the objList after remove selected row element  
                }

            }
},*/

    // CriticalIssue function for delete the row 
    removeCriticalIssueRow: function(component, event, helper) {
        debugger;
            console.log('dynRow removeDeletedRow CriticalIssue');
            component.set("v.notifMsgDelCriticalIssue", "");        
        	component.set("v.notifMsgCriticalIssue", ""); 
            // get the selected row Index for delete, from Lightning Event Attribute  
            var index = event.getParam("indexVar");
            var CriticalIssueId = event.getParam("CriticalIssueId");
            console.log('dynRow removeDeletedRow index: ' + index );
            console.log('removal ' + "{!v.section}" +'CriticalIssueId: ' + CriticalIssueId);
            
        	if(CriticalIssueId != null){
			    var action = component.get("c.removeAccountPlans");
                action.setParams({"accountPlanObjList": component.get("v.CriticalIssueList"), "accountPlanId": component.get("v.recordId"), "apObjid": CriticalIssueId});
                action.setCallback(this, function(response) {
                    var state = response.getState();
                    if (state === "SUCCESS") {
                        console.log('return value: ' + response.getReturnValue());
                        component.set("v.CriticalIssueList", response.getReturnValue());//set data in the page variable
                        component.set("v.notifMsgDelCriticalIssue", "Removed CriticalIssue Successfully!");
                        if(component.get("v.CriticalIssueList").length == 0){
                            this.createObjectData(component);//leave atleast a row.
                        }                              
                    }
                });
                $A.enqueueAction(action);
            }else{
                    console.log('dynRow removeDeletedRow CriticalIssue List index: ' + index);
                    var allRowsList = component.get("v.CriticalIssueList");
                if(allRowsList.length == 1){
                 	   alert('This is a place holder row, which cannot be deleted!');
                }else{                
                    allRowsList.splice(index, 1);
                    component.set("v.CriticalIssueList", allRowsList); // set the objList after remove selected row element  
                }

            }
},

    // MarketImpact function for delete the row 
    removeMarketImpactRow: function(component, event, helper) {
            console.log('dynRow removeDeletedRow MarketImpact');
            component.set("v.notifMsgDelMarketImpact", "");        
        	component.set("v.notifMsgMarketImpact", ""); 
            // get the selected row Index for delete, from Lightning Event Attribute  
            var index = event.getParam("indexVar");
            var MarketImpactId = event.getParam("MarketImpactId");
            console.log('dynRow removeDeletedRow index: ' + index );
            console.log('removal ' + "{!v.section}" +'MarketImpactId: ' + MarketImpactId);
            
        	if(MarketImpactId != null){
			    var action = component.get("c.removeAccountPlans");
                action.setParams({"accountPlanObjList": component.get("v.MarketImpactList"), "accountPlanId": component.get("v.recordId"), "apObjid": MarketImpactId});
                action.setCallback(this, function(response) {
                    var state = response.getState();
                    if (state === "SUCCESS") {
                        console.log('return value: ' + response.getReturnValue());
                        component.set("v.MarketImpactList", response.getReturnValue());//set data in the page variable
                        component.set("v.notifMsgDelMarketImpact", "Removed MarketImpact Successfully!");
                        if(component.get("v.MarketImpactList").length == 0){
                            this.createObjectData(component);//leave atleast a row.
                        }                            
                    }
                });
                $A.enqueueAction(action);
            }else{
                    console.log('dynRow removeDeletedRow MarketImpact List index: ' + index);
                    var allRowsList = component.get("v.MarketImpactList");
                if(allRowsList.length == 1){
                 	   alert('This is a place holder row, which cannot be deleted!');
                }else{                
                    allRowsList.splice(index, 1);
                    component.set("v.MarketImpactList", allRowsList); // set the objList after remove selected row element  
                }

            }
},

    // DesiredOutcome function for delete the row 
    removeDesiredOutcomeRow: function(component, event, helper) {
            console.log('dynRow removeDeletedRow DesiredOutcome');
            component.set("v.notifMsgDelDesiredOutcome", "");        
        	component.set("v.notifMsgDesiredOutcome", ""); 
            // get the selected row Index for delete, from Lightning Event Attribute  
            var index = event.getParam("indexVar");
            var DesiredOutcomeId = event.getParam("DesiredOutcomeId");
            console.log('dynRow removeDeletedRow index: ' + index );
            console.log('removal ' + "{!v.section}" +'DesiredOutcomeId: ' + DesiredOutcomeId);
            
        	if(DesiredOutcomeId != null){
			    var action = component.get("c.removeAccountPlans");
                action.setParams({"accountPlanObjList": component.get("v.DesiredOutcomeList"), "accountPlanId": component.get("v.recordId"), "apObjid": DesiredOutcomeId});
                action.setCallback(this, function(response) {
                    var state = response.getState();
                    if (state === "SUCCESS") {
                        console.log('return value: ' + response.getReturnValue());
                        component.set("v.DesiredOutcomeList", response.getReturnValue());//set data in the page variable
                        component.set("v.notifMsgDelDesiredOutcome", "Removed DesiredOutcome Successfully!");
                        if(component.get("v.DesiredOutcomeList").length == 0){
                            this.createObjectData(component);//leave atleast a row.
                        }                            
                    }
                });
                $A.enqueueAction(action);
            }else{
                    console.log('dynRow removeDeletedRow DesiredOutcome List index: ' + index);
                    var allRowsList = component.get("v.DesiredOutcomeList");
                if(allRowsList.length == 1){
                 	   alert('This is a place holder row, which cannot be deleted!');
                }else{                
                    allRowsList.splice(index, 1);
                    component.set("v.DesiredOutcomeList", allRowsList); // set the objList after remove selected row element  
                }
            }
},
    
    
})