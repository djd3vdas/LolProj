({
    // function call on component Load
    doInit: function(component, event, helper) {
        // create a Default RowItem [ Account Planning Instance] on first time Component Load
        // by call this helper function  
        console.log('Inside dynRowCtr do Init');
        
       //debugger;
        helper.getSwotList(component);
        helper.getCriticalIssueList(component);
        helper.getMarketImpactList(component);
        helper.getDesiredOutcomeList(component);
        
    },
    
    // function for save the Records 
    Save: function(component, event, helper) {
                   var section = component.get("v.section");
            var action = component.get("c.saveAccountPlan");
            if('Swot' == section){
                debugger;
                component.set("v.notifMsgSwot", ""); component.set("v.notifMsgDelSwot", "");
                action.setParams({"accountPlanObjList": component.get("v.SwotList"), "accountPlanId": component.get("v.recordId")});  
                action.setCallback(this, function(response) {
                    var state = response.getState();
                    if (state === "SUCCESS") {
                        console.log('Save SUCCESS!!');
                        //component.set("v.notifMsgSwot", "Swot was Added Successfully!");                      
                       //alert('Your Discovery changes have been saved successfully!');
                       component.set("v.viewEditFlag", "Cancel");
                        helper.getSwotList(component);
                    }else{
                        console.log('Save Error !! ' + state);
                    }
                    
                
               
                });
                  $A.enqueueAction(action);               
            }
                if('Critical Issue' == section){
                    debugger;
                    component.set("v.notifMsgCriticalIssue", ""); component.set("v.notifMsgDelCriticalIssue", "");                    
                    action.setParams({"accountPlanObjList": component.get("v.CriticalIssueList"), "accountPlanId": component.get("v.recordId")});                        
					action.setCallback(this, function(response) {
                        var state = response.getState();
                        if (state === "SUCCESS") {
                            console.log('Save CriticalIssue SUCCESS!!');
                                                                               
                            helper.getCriticalIssueList(component);
                        }else{
                            console.log('Save CriticalIssue Error !! ' + state);
                        }
                         
                    
                     
                    });
                   $A.enqueueAction(action);                       
                }
            if('Market Impact' == section){
                    component.set("v.notifMsgMarketImpact", ""); component.set("v.notifMsgDelMarketImpact", "");                    
                    action.setParams({"accountPlanObjList": component.get("v.MarketImpactList"), "accountPlanId": component.get("v.recordId")});                        
					action.setCallback(this, function(response) {
                        var state = response.getState();
                        if (state === "SUCCESS") {
                            console.log('Save MarketImpact SUCCESS!!');
                            //component.set("v.notifMsgMarketImpact", "Market Impact was Added Successfully!");                            
                            helper.getMarketImpactList(component);
                        }else{
                            console.log('Save Market Impact Error !! ' + state);
                        }
                    });
                    $A.enqueueAction(action);                       
            	}
            if('Desired Outcome' == section){
                    component.set("v.notifMsgDesiredOutcome", ""); component.set("v.notifMsgDelDesiredOutcome", "");                    
                    action.setParams({"accountPlanObjList": component.get("v.DesiredOutcomeList"), "accountPlanId": component.get("v.recordId")});                        
					action.setCallback(this, function(response) {
                        var state = response.getState();
                        if (state === "SUCCESS") {
                            console.log('Save DesiredOutcome SUCCESS!!');
                            //component.set("v.notifMsgDesiredOutcome", "Desired Outcome was Added Successfully!");                            
                            helper.getDesiredOutcomeList(component);
                        }else{
                            console.log('Save Desired Outcome Error !! ' + state);
                        }
                    });
                    $A.enqueueAction(action);                       
            	}
            if('Objective' == section){
                    component.set("v.notifMsgObjective", ""); component.set("v.notifMsgDelObjective", "");                    
                    action.setParams({"accountPlanObjList": component.get("v.ObjectiveList"), "accountPlanId": component.get("v.recordId")});                        
					action.setCallback(this, function(response) {
                        var state = response.getState();
                        if (state === "SUCCESS") {
                            console.log('Save Objective SUCCESS!!');
                            //component.set("v.notifMsgObjective", "Objective was Added Successfully!");  
                                                      
                            helper.getObjectiveList(component);
                        }else{
                            console.log('Save Objective Error !! ' + state);
                        }
                    });
                    $A.enqueueAction(action);                       
            	} 
            
    },
 
    // function for create new object Row in Account Plan List 
    addNewRow: function(component, event, helper) {
        helper.createObjectDataonAdd(component);
    },
 
    // function for delete the row 
    removeDeletedRow: function(component, event, helper) {
        console.log('dynRow removeDeletedRow main');
        var section = component.get("v.section");
        console.log('dynRow removeDeletedRow section: ' + section);
        if('Swot' == section){
        	 console.log('dynRow calling remove Swot');
			helper.reomveSwotRow(component, event, helper);    
        }
        if('Strength' == section){
            console.log('dynRow calling remove strength');
			helper.removeStrengthRow(component, event, helper);
        }else if('Weakness' == section){
            console.log('dynRow calling remove Weakness');
			helper.removeWeaknessRow(component, event, helper);
		}else if('Opportunity' == section){
            console.log('dynRow calling remove Opportunity');
			helper.removeOpportunityRow(component, event, helper);
        }else if('Threat' == section){
            console.log('dynRow calling remove Threat');
			helper.removeThreatRow(component, event, helper);
        }else if('Critical Issue' == section){
            console.log('dynRow calling remove CriticalIssue');
			helper.removeCriticalIssueRow(component, event, helper);
        }else if('Market Impact' == section){
            console.log('dynRow calling remove MarketImpact');
			helper.removeMarketImpactRow(component, event, helper);
        }else if('Desired Outcome' == section){
            console.log('dynRow calling remove DesiredOutcome');
			helper.removeDesiredOutcomeRow(component, event, helper);
        }else if('Objective' == section){
            console.log('dynRow calling remove Objective');
			helper.removeObjectiveRow(component, event, helper);
        }
    },
})