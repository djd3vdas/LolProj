({
//Objective
    handleLoadObjective: function(cmp, event, helper) {
        cmp.set('v.showSpinner', false);
        console.log("handleLoadObjective recordid: " + cmp.get("{!v.recordId}"));
    },

    handleSubmitObjective: function(cmp, event, helper) {
        cmp.set('v.disabledObjective', true);
        cmp.set('v.showSpinner', true);
        
		var recordId = cmp.get("{!v.recordId}");
        event.preventDefault(); // stop form submission
        var eventFields = event.getParam("fields");
        eventFields["Account_Plan__C"] = recordId;
        cmp.find('Objective').submit(eventFields);        
        
    },

    handleErrorObjective: function(cmp, event, helper) {
        // errors are handled by lightning:inputField and lightning:nessages
        // so this just hides the spinnet
        cmp.set('v.showSpinner', false);
    },

    handleSuccessObjective: function(cmp, event, helper) {
        cmp.set('v.showSpinner', false);
        cmp.set('v.savedObjective', true);
        var payload = event.getParams().response;
		console.log('The Objective id received' + payload.id);
        cmp.set("v.objectiveId", payload.id);
    },

// Strategy
    handleLoadStrategy: function(cmp, event, helper) {
        cmp.set('v.showSpinner', false);
    },

    handleSubmitStrategy: function(cmp, event, helper) {
        cmp.set('v.disabledStrategy', true);
        cmp.set('v.showSpinner', true);
        
        event.preventDefault(); // stop form submission
        var eventFields = event.getParam("fields");
        console.log('cmp.get("{!v.objectiveId}"): ' + cmp.get("{!v.objectiveId}"));
        eventFields["Account_Plan_Objective__c"] = cmp.get("{!v.objectiveId}");
        cmp.find('Strategy').submit(eventFields);           
    },

    handleErrorStrategy: function(cmp, event, helper) {
        // errors are handled by lightning:inputField and lightning:nessages
        // so this just hides the spinnet
        cmp.set('v.showSpinner', false);
    },

    handleSuccessStrategy: function(cmp, event, helper) {
        cmp.set('v.showSpinner', false);
        cmp.set('v.savedStrategy', true);
        var payload = event.getParams().response;
		console.log('The Strategy id received' + payload.id);
        cmp.set("v.strategyId", payload.id);
    },
//Tactic

    handleLoadTactic: function(cmp, event, helper) {
        cmp.set('v.showSpinner', false);
    },

    handleSubmitTactic: function(cmp, event, helper) {
        cmp.set('v.disabledTactic', true);
        cmp.set('v.showSpinner', true);
        event.preventDefault(); // stop form submission
        var eventFields = event.getParam("fields");
        eventFields["Account_Plan_Strategy__c"] = cmp.get("{!v.strategyId}");
        cmp.find('Tactic').submit(eventFields);          
    },

    handleErrorTactic: function(cmp, event, helper) {
        // errors are handled by lightning:inputField and lightning:nessages
        // so this just hides the spinnet
        cmp.set('v.showSpinner', false);
    },

    handleSuccessTactic: function(cmp, event, helper) {
        cmp.set('v.showSpinner', false);
        cmp.set('v.savedTactic', true);
        var payload = event.getParams().response;
		console.log('The Tactic id received' + payload.id);
        cmp.set("v.tacticId", payload.id);        
    },
    
//SaveALL    
        saveall: function(cmp, event, helper) {
        cmp.set('v.disabled', true);
        cmp.set('v.showSpinner', true);
        
		var recordId = cmp.get("{!v.recordId}");
        console.log("handleSubmitObjective recordid: " + recordId);
          event.preventDefault(); // stop form submission
          var eventFields = event.getParam("fields");
          eventFields["Account_Plan__C"] = recordId;
          cmp.find('Objective').submit(eventFields);        
       
    },
//Edit Begins

//ObjectiveE
    handleLoadObjectiveE: function(cmp, event, helper) {
        cmp.set('v.showSpinner', false);
    },

    handleSubmitObjectiveE: function(cmp, event, helper) {
        cmp.set('v.disabled', true);
        cmp.set('v.showSpinner', true);
    },

    handleErrorObjectiveE: function(cmp, event, helper) {
        // errors are handled by lightning:inputField and lightning:nessages
        // so this just hides the spinnet
        cmp.set('v.showSpinner', false);
    },

    handleSuccessObjectiveE: function(cmp, event, helper) {
        cmp.set('v.showSpinner', false);
        cmp.set('v.saved', true);
        var payload = event.getParams().response;
		console.log('The Objective id received' + payload.id);
    },

// StrategyE
    handleLoadStrategyE: function(cmp, event, helper) {
        cmp.set('v.showSpinner', false);
    },

    handleSubmitStrategyE: function(cmp, event, helper) {
        cmp.set('v.disabled', true);
        cmp.set('v.showSpinner', true);
    },

    handleErrorStrategyE: function(cmp, event, helper) {
        // errors are handled by lightning:inputField and lightning:nessages
        // so this just hides the spinnet
        cmp.set('v.showSpinner', false);
    },

    handleSuccessStrategyE: function(cmp, event, helper) {
        cmp.set('v.showSpinner', false);
        cmp.set('v.saved', true);
        var payload = event.getParams().response;
		console.log('The Strategy id received' + payload.id);
    },
//TacticE

    handleLoadTacticE: function(cmp, event, helper) {
        cmp.set('v.showSpinner', false);
    },

    handleSubmitTacticE: function(cmp, event, helper) {
        cmp.set('v.disabled', true);
        cmp.set('v.showSpinner', true);
    },

    handleErrorTacticE: function(cmp, event, helper) {
        // errors are handled by lightning:inputField and lightning:nessages
        // so this just hides the spinnet
        cmp.set('v.showSpinner', false);
    },

    handleSuccessTacticE: function(cmp, event, helper) {
        cmp.set('v.showSpinner', false);
        cmp.set('v.saved', true);
        var payload = event.getParams().response;
		console.log('The Tactic id received' + payload.id);
    },    
    showadd : function(component, event, helper) {
        var btn = event.getSource().get('v.value');
        if(btn == 'showadd'){
            component.set('v.showadd',true);            
        }else {
            component.set('v.showadd',false);            
        }
    }  
    
});