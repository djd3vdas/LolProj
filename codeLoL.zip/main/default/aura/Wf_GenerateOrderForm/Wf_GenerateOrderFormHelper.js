({
    generateAgreement : function(component, event, selectedVal){
         //alert("in generateAgreement");
        component.set("v.showModal",false);
        var isRetailer=false;
        var isGrower=false;
        if(selectedVal.includes('R') && selectedVal.includes('G')){
       		isRetailer=true;
            isGrower=true;  
        } else if(selectedVal.includes('R')){
          	isRetailer=true; 
        } else if(selectedVal.includes('G')){
             isGrower=true;
        }
    	var spinner = component.find("mySpinner");
        $A.util.removeClass(spinner, "slds-hide");
        component.set('v.openModal', false);
        //server-call to generate Order Form
        var action = component.get("c.generateOrderform");
        action.setParams({
            planId: component.get("v.recordId"),
            isRetailer: isRetailer,
            isGrower: isGrower
        });
        // callback behavior  when response is received
        action.setCallback(this, function (response) {
            var state = response.getState();
           // alert(state);
            var getReturnVal = response.getReturnValue();
             //alert("getReturnVal--"+getReturnVal);
            component.set("v.openModal", true);
            //alert(getReturnVal);
            if (state === "SUCCESS") {
                // component.set('v.spin',false);
                component.set('v.showSpinner', false);
                var spinner = component.find("mySpinner");
                $A.util.addClass(spinner, "slds-hide");
                var toastEvent = $A.get("e.force:showToast");
                if (getReturnVal == true) {
                    component.set("v.message", "The ORDER FORM has been generated successfully.");
                    toastEvent.setParams({
                        "title": "Success!",
                        "message": "The ORDER FORM has been generated successfully.",
                        "type": "Success"
                    });

                } else if (getReturnVal == false) {
                    component.set("v.message", "The ORDER FORM generation has error.");
                    toastEvent.setParams({
                        "title": "error!",
                        "message": "The ORDER FORM generation has error.",
                        "type": "error"
                    });
                } 
                toastEvent.fire();
            } else {
                component.set('v.showSpinner', true);
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "title": "error!",
                    "message": "The ORDER FORM generation has error.",
                    "type": "error"
                });
                toastEvent.fire();
            }
            var dismissActionPanel = $A.get("e.force:closeQuickAction");
            dismissActionPanel.fire();

            setTimeout(function () {
                location.reload();
            }, 3000)

        });
        // Send action off to be executed
        $A.enqueueAction(action);
	}
})