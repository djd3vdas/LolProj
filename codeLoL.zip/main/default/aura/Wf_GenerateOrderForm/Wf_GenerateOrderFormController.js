({	
    //onload method to check if order form has been generated already or not
    doInit : function (component, event, helper){
        var spinner = component.find("mySpinner");
        $A.util.removeClass(spinner, "slds-hide");
        var action = component.get("c.checkOrderFormStatus");
        action.setParams({
            planId: component.get("v.recordId")
        });
        // callback behavior  when response is received
        action.setCallback(this, function (response) {
            var state = response.getState();
            //alert(state);
            var getReturnVal = response.getReturnValue();
            // alert("getReturnVal--"+getReturnVal);
            var dismissActionPanel = $A.get("e.force:closeQuickAction");
            //alert(getReturnVal);
            if (state === "SUCCESS") {
                // component.set('v.spin',false);
                component.set('v.showSpinner', false);
                var spinner = component.find("mySpinner");
                $A.util.addClass(spinner, "slds-hide");
                var toastEvent = $A.get("e.force:showToast");
                if (getReturnVal == 'GENERATED') {
                    component.set("v.message", "The ORDER FORM has already been generated. You cannot generate it again.");
                    toastEvent.setParams({
                        "title": "error!",
                        "message": "The ORDER FORM has already been generated. You cannot generate it again.",
                        "type": "error"
                    });
                    
                toastEvent.fire();
                dismissActionPanel.fire();
                }else if(getReturnVal == 'NOTGENERATED'){
                    component.set("v.showModal",true);
                }else if(getReturnVal=='VOID'){
                     var status =getReturnVal.split(",");
                    toastEvent.setParams({
                        "title": "error!",
                        "message": "The ORDER FORM cannot be generated as not a single Policies are  in Locked Status",
                        "type": "error"
                    });
                    
                toastEvent.fire();
                dismissActionPanel.fire();
                }else if(getReturnVal == 'EXCEPTION'){
                    toastEvent.setParams({
                        "title": "error!",
                        "message": "The ORDER FORM generation has an error. Kindly contact Administrator.",
                        "type": "error"
                    });
                    
                toastEvent.fire();
                dismissActionPanel.fire();
                }
            } else {
                component.set('v.showSpinner', true);
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "title": "error!",
                    "message": "The ORDER FORM generation has an error. Kindly contact Administrator",
                    "type": "error"
                });
                toastEvent.fire();
                dismissActionPanel.fire();
            }
            });
        // Send action off to be executed
        $A.enqueueAction(action);

    },
    
    //this method initiates the Order Form Generation based on selection of Grower & Retailer
    handleOK: function (component, event, helper) {
        //check if atleast 1 option selected for Generating Order Form
        var selectedVal =component.get("v.selectedVal");
        //alert(selectedVal);
        if(selectedVal=="" || selectedVal=="Undefined"){
        	component.set('v.showErrorMessage', true);
        }
        else{
          //alert("in else");
          helper.generateAgreement(component, event, selectedVal);
        }
    },
     handleCancel : function(component, event, helper) {
  	 	var dismissActionPanel = $A.get("e.force:closeQuickAction");
        dismissActionPanel.fire();
 	 },
     //handler to enable disable Ok button on selection of check box item 
     handleChange : function(component, event, helper) {
  	 	 var selectedVal=component.get("v.selectedVal");
         if(selectedVal!='' && selectedVal!=undefined){
             component.set("v.showOk",true);
         }else{
             component.set("v.showOk",false);
         }
 	 },
    showSpinner: function (component, event, helper) {
        var spinner = component.find("mySpinner");
        $A.util.removeClass(spinner, "slds-hide");
    },

    hideSpinner: function (component, event, helper) {
        var spinner = component.find("mySpinner");
        $A.util.addClass(spinner, "slds-hide");
    }

})